package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.BossActionsRepository
import com.example.data.DeviceActionManager
import com.example.data.SecurePreferences
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("FRIDAY", appName)
    }

    @Test
    fun `test secure preferences default boss name and leda voice`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val prefs = SecurePreferences(context)
        assertEquals("Mr. Shrabon", prefs.getBossName())
        assertEquals("Leda", prefs.getSelectedVoice())
        assertTrue(prefs.isCallScreeningEnabled())
    }

    @Test
    fun `test boss actions repository creates and stores records`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = BossActionsRepository(context)
        val testCall = repo.addScreenedCall(
            callerName = "John Doe",
            callerNumber = "+1234567890",
            messageText = "Urgent message for Mr. Shrabon"
        )
        assertNotNull(testCall.id)
        assertTrue(repo.screenedCalls.value.any { it.callerName == "John Doe" })

        val testFile = repo.recordCreatedFile(
            fileName = "task_list.txt",
            filePath = "/data/user/0/com.example/files/task_list.txt",
            content = "1. Deploy FRIDAY system\n2. Call client",
            sizeBytes = 42L
        )
        assertNotNull(testFile.id)
        assertTrue(repo.createdFiles.value.any { it.fileName == "task_list.txt" })
    }

    @Test
    fun `test device action manager generates call screening intro in leda voice`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val prefs = SecurePreferences(context)
        val repo = BossActionsRepository(context)
        val actionManager = DeviceActionManager(context, repo, prefs)
        val intro = actionManager.getCallAssistantIntro("Alice")
        assertTrue(intro.contains("FRIDAY"))
        assertTrue(intro.contains("Mr. Shrabon"))
        assertTrue(intro.contains("Alice"))
    }
}
