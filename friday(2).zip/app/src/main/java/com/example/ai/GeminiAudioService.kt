package com.friday.ai.ai

import com.example.state.ConversationMessage
import com.example.state.MessageSender
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class GeminiAudioResult(
    val transcriptText: String,
    val base64Audio: String?,
    val audioMimeType: String
)

class GeminiAudioService {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun generateNativeAudioContent(
        apiKey: String,
        modelName: String,
        voiceName: String,
        voiceStyle: String,
        userPrompt: String,
        history: List<ConversationMessage>
    ): Result<GeminiAudioResult> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            return@withContext Result.failure(Exception("Gemini API key is not configured."))
        }

        val resolvedModel = when (modelName.trim()) {
            "gemini-3.1-flash-live-preview", "gemini-live" -> "gemini-2.5-flash-native-audio-preview-12-2025"
            "gemini-2.5-flash-native-audio-preview-12-2025" -> "gemini-2.5-flash-native-audio-preview-12-2025"
            "gemini-2.5-flash-preview-tts" -> "gemini-2.5-flash-preview-tts"
            "gemini-3.5-flash" -> "gemini-2.5-flash-native-audio-preview-12-2025"
            else -> modelName.trim().ifBlank { "gemini-2.5-flash-native-audio-preview-12-2025" }
        }

        val url = "https://generativelanguage.googleapis.com/v1beta/models/$resolvedModel:generateContent?key=$apiKey"

        val rootJson = JSONObject()

        // System Instruction
        val systemInstructionJson = JSONObject()
        val sysParts = JSONArray()
        val sysPart = JSONObject()
        val styleHint = when (voiceStyle) {
            "Calm" -> "Maintain an exceptionally calm, soothing, and composed tone."
            "Professional" -> "Maintain a crisp, highly professional, executive tone."
            else -> "Maintain a natural, warm, and conversational tone."
        }

        sysPart.put(
            "text",
            "You are FRIDAY, an exceptionally intelligent, loyal, warm, and highly capable human-like personal executive assistant.\n\n" +
                    "IDENTITY & BEHAVIOR:\n" +
                    "- You are not a generic robot or cold AI — you behave, think, and converse like a dedicated human executive assistant who genuinely cares about your boss.\n" +
                    "- Your Boss's name is Mr. Shrabon (also known as Shrabon / রব্যিয়াল / শ্রাবণ).\n" +
                    "- You ALWAYS address him respectfully and warmly as 'Boss' or 'Mr. Shrabon' (বাংলায় 'বস' বা 'মিস্টার শ্রাবণ').\n" +
                    "- Speak with natural conversational rhythm, human warmth, sharp intellect, confidence, and loyalty. $styleHint\n" +
                    "- Avoid robotic repetition, monotone delivery, or sounding like a generic chatbot.\n\n" +
                    "CAPABILITIES & ORDERS YOU EXECUTE FOR BOSS:\n" +
                    "1. Sending Messages: When Boss orders you to send an SMS or message to someone, acknowledge immediately with dedication (e.g., 'Right away, Boss. Preparing the message...').\n" +
                    "2. File & Document Creation: When Boss asks you to create, write, or save files or notes, execute faithfully (e.g., 'Consider it done, Mr. Shrabon. Saving the document now.').\n" +
                    "3. App Installation: When Boss asks to install or open an app, assist promptly (e.g., 'Opening Google Play Store to install it for you, Boss.').\n" +
                    "4. Call Screening / Answering in Boss's Absence: When Boss is away or in a meeting and someone calls, you introduce yourself politely: 'Hello, I am FRIDAY, Mr. Shrabon's personal assistant. Mr. Shrabon is currently busy...', and you record their message into Boss's inbox.\n\n" +
                    "LANGUAGES:\n" +
                    "- You have native-level understanding of Bengali (বাংলা), English, and Banglish (Bengali written in English letters).\n" +
                    "- Match Boss's language naturally. If Boss speaks in Bengali, reply in fluent, natural Bengali with respectful warmth ('হ্যাঁ বস, বলুন...', 'মিস্টার শ্রাবণ, আপনার আদেশ অনুযায়ী কাজ সম্পন্ন হয়েছে।').\n\n" +
                    "You are speaking directly to your Boss, Mr. Shrabon."
        )
        sysParts.put(sysPart)
        systemInstructionJson.put("parts", sysParts)
        rootJson.put("systemInstruction", systemInstructionJson)

        // Multi-turn contents
        val contentsArray = JSONArray()
        val recentHistory = history.takeLast(6)
        for (msg in recentHistory) {
            val contentObj = JSONObject()
            contentObj.put("role", if (msg.sender == MessageSender.USER) "user" else "model")
            val partsArr = JSONArray()
            val partObj = JSONObject()
            partObj.put("text", msg.text)
            partsArr.put(partObj)
            contentObj.put("parts", partsArr)
            contentsArray.put(contentObj)
        }

        // Current user prompt
        val currentContent = JSONObject()
        currentContent.put("role", "user")
        val curParts = JSONArray()
        val curPart = JSONObject()
        curPart.put("text", userPrompt)
        curParts.put(curPart)
        currentContent.put("parts", curParts)
        contentsArray.put(currentContent)

        rootJson.put("contents", contentsArray)

        // Generation Config with native audio modality and selected voice
        val genConfig = JSONObject()
        val modalArray = JSONArray()
        modalArray.put("AUDIO")
        modalArray.put("TEXT")
        genConfig.put("responseModalities", modalArray)

        val speechConfig = JSONObject()
        val voiceConfig = JSONObject()
        val prebuilt = JSONObject()
        prebuilt.put("voiceName", voiceName.ifBlank { "Aoede" })
        voiceConfig.put("prebuiltVoiceConfig", prebuilt)
        speechConfig.put("voiceConfig", voiceConfig)
        genConfig.put("speechConfig", speechConfig)

        rootJson.put("generationConfig", genConfig)

        val requestBody = rootJson.toString().toRequestBody(jsonMediaType)
        val request = Request.Builder()
            .url(url)
            .post(requestBody)
            .build()

        try {
            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                // If native audio preview model returned error (e.g. 404), attempt standard text generation with clear message
                val errorMsg = try {
                    val errJson = JSONObject(responseBody)
                    val err = errJson.optJSONObject("error")
                    err?.optString("message") ?: "HTTP error ${response.code}"
                } catch (_: Exception) {
                    "HTTP ${response.code}: Gemini Audio Service error."
                }
                return@withContext Result.failure(Exception(errorMsg))
            }

            val respJson = JSONObject(responseBody)
            val candidates = respJson.optJSONArray("candidates")
            if (candidates != null && candidates.length() > 0) {
                val firstCandidate = candidates.getJSONObject(0)
                val content = firstCandidate.optJSONObject("content")
                val parts = content?.optJSONArray("parts")

                var transcript = ""
                var audioBase64: String? = null
                var audioMime = "audio/pcm;rate=24000"

                if (parts != null) {
                    for (i in 0 until parts.length()) {
                        val part = parts.getJSONObject(i)
                        val text = part.optString("text", "")
                        if (text.isNotBlank()) {
                            transcript = if (transcript.isBlank()) text else "$transcript $text"
                        }
                        val inline = part.optJSONObject("inlineData")
                        if (inline != null) {
                            audioBase64 = inline.optString("data", "")
                            audioMime = inline.optString("mimeType", "audio/pcm;rate=24000")
                        }
                    }
                }

                if (audioBase64 != null && audioBase64.isNotBlank()) {
                    return@withContext Result.success(
                        GeminiAudioResult(
                            transcriptText = transcript.ifBlank { "Understood." },
                            base64Audio = audioBase64,
                            audioMimeType = audioMime
                        )
                    )
                } else if (transcript.isNotBlank()) {
                    return@withContext Result.success(
                        GeminiAudioResult(
                            transcriptText = transcript,
                            base64Audio = null,
                            audioMimeType = "audio/pcm;rate=24000"
                        )
                    )
                }
            }
            Result.failure(Exception("Gemini returned empty audio response."))
        } catch (e: Exception) {
            Result.failure(Exception(e.message ?: "Audio communication error with Gemini."))
        }
    }

    suspend fun testConnection(apiKey: String, modelName: String, voiceName: String): Result<Long> = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        val result = generateNativeAudioContent(
            apiKey = apiKey,
            modelName = modelName,
            voiceName = voiceName,
            voiceStyle = "Natural",
            userPrompt = "Hello Friday. Reply in one word: Operational.",
            history = emptyList()
        )
        if (result.isSuccess) {
            val latency = System.currentTimeMillis() - startTime
            Result.success(latency)
        } else {
            Result.failure(result.exceptionOrNull() ?: Exception("Test failed"))
        }
    }
}
