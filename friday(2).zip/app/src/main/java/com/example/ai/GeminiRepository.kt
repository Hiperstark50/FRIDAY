package com.friday.ai.ai

import com.example.data.ConversationRepository
import com.example.data.SecurePreferences
import com.example.state.ConversationMessage
import com.example.state.MessageSender

class GeminiRepository(
    private val geminiAudioService: GeminiAudioService,
    private val securePreferences: SecurePreferences,
    private val conversationRepository: ConversationRepository
) {
    suspend fun askFridayNativeAudio(prompt: String): Result<GeminiAudioResult> {
        val apiKey = securePreferences.getEffectiveApiKey()
        val model = securePreferences.getSelectedModel()
        val voice = securePreferences.getSelectedVoice()
        val voiceStyle = securePreferences.getVoiceStyle()
        val history = conversationRepository.getHistory()

        if (apiKey.isBlank()) {
            return Result.failure(Exception("Gemini API key is required. Please check your key in Settings."))
        }

        return geminiAudioService.generateNativeAudioContent(
            apiKey = apiKey,
            modelName = model,
            voiceName = voice,
            voiceStyle = voiceStyle,
            userPrompt = prompt,
            history = history
        )
    }

    suspend fun testConnection(): Result<Long> {
        val apiKey = securePreferences.getEffectiveApiKey()
        val model = securePreferences.getSelectedModel()
        val voice = securePreferences.getSelectedVoice()
        return geminiAudioService.testConnection(apiKey, model, voice)
    }
}
