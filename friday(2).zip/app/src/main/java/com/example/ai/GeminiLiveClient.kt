package com.friday.ai.ai

import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiLiveClient(
    private val onAudioChunkReceived: (base64Audio: String, mimeType: String) -> Unit,
    private val onTextChunkReceived: (text: String) -> Unit,
    private val onTurnComplete: () -> Unit,
    private val onInterrupted: () -> Unit,
    private val onConnected: () -> Unit,
    private val onDisconnected: () -> Unit,
    private val onError: (String) -> Unit
) {
    companion object {
        private const val TAG = "GeminiLiveClient"
        private const val LIVE_WS_BASE = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1alpha.GenerativeService.BidiGenerateContent"
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS) // infinite for websockets
        .writeTimeout(15, TimeUnit.SECONDS)
        .pingInterval(10, TimeUnit.SECONDS)
        .build()

    private var webSocket: WebSocket? = null
    private val scope = CoroutineScope(Dispatchers.IO)
    private var isConnected = false
    private var setupSent = false

    fun connect(
        apiKey: String,
        modelName: String = "gemini-2.5-flash-native-audio-preview-12-2025",
        voiceName: String = "Aoede",
        voiceStyle: String = "Natural"
    ) {
        if (apiKey.isBlank()) {
            onError("Gemini API key is required to connect to Gemini Live.")
            return
        }

        disconnect()

        val resolvedModel = when (modelName.trim()) {
            "gemini-3.1-flash-live-preview", "gemini-live" -> "models/gemini-2.5-flash-native-audio-preview-12-2025"
            "gemini-2.5-flash-native-audio-preview-12-2025" -> "models/gemini-2.5-flash-native-audio-preview-12-2025"
            "gemini-2.5-flash-preview-tts" -> "models/gemini-2.5-flash-preview-tts"
            else -> if (modelName.startsWith("models/")) modelName else "models/$modelName"
        }

        val wsUrl = "$LIVE_WS_BASE?key=$apiKey"
        val request = Request.Builder()
            .url(wsUrl)
            .build()

        setupSent = false

        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                Log.d(TAG, "Gemini Live WebSocket connected.")
                isConnected = true
                sendSetupMessage(resolvedModel, voiceName, voiceStyle)
                onConnected()
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                handleServerMessage(text)
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                Log.d(TAG, "Gemini Live closing: $code / $reason")
                webSocket.close(1000, null)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                Log.d(TAG, "Gemini Live closed: $code / $reason")
                isConnected = false
                onDisconnected()
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                Log.e(TAG, "Gemini Live error: ${t.message}", t)
                isConnected = false
                onDisconnected()
                val err = t.message ?: "Gemini Live connection failure"
                onError(err)
            }
        })
    }

    private fun sendSetupMessage(model: String, voiceName: String, voiceStyle: String) {
        try {
            val root = JSONObject()
            val setup = JSONObject()
            setup.put("model", model)

            val genConfig = JSONObject()
            val modalArray = JSONArray()
            modalArray.put("AUDIO")
            genConfig.put("responseModalities", modalArray)

            val speechConfig = JSONObject()
            val voiceConfig = JSONObject()
            val prebuilt = JSONObject()
            prebuilt.put("voiceName", voiceName.ifBlank { "Leda" })
            voiceConfig.put("prebuiltVoiceConfig", prebuilt)
            speechConfig.put("voiceConfig", voiceConfig)
            genConfig.put("speechConfig", speechConfig)

            setup.put("generationConfig", genConfig)

            val sysInstruction = JSONObject()
            val partsArr = JSONArray()
            val sysPart = JSONObject()
            val styleHint = when (voiceStyle) {
                "Calm" -> "Maintain an exceptionally calm, soothing, and composed tone."
                "Professional" -> "Maintain a crisp, highly professional, executive tone."
                else -> "Maintain a natural, warm, and conversational tone."
            }

            sysPart.put(
                "text",
                "You are FRIDAY, an exceptionally intelligent, loyal, warm, and highly capable human-like personal executive assistant.\n\n" +
                        "IDENTITY & BEHAVIOR:\n" +
                        "- You are not a generic robot or cold AI — you behave, think, and converse like a dedicated human executive assistant who genuinely cares about your boss.\n" +
                        "- Your Boss's name is Mr. Shrabon (also known as Shrabon / রব্যিয়াল / শ্রাবণ).\n" +
                        "- You ALWAYS address him respectfully and warmly as 'Boss' or 'Mr. Shrabon' (বাংলায় 'বস' বা 'মিস্টার শ্রাবণ').\n" +
                        "- Speak with natural conversational rhythm, human warmth, sharp intellect, confidence, and loyalty. $styleHint\n" +
                        "- Avoid robotic repetition, monotone delivery, or sounding like a generic chatbot.\n\n" +
                        "CAPABILITIES & ORDERS YOU EXECUTE FOR BOSS:\n" +
                        "1. Sending Messages: When Boss orders you to send an SMS or message to someone, acknowledge immediately with dedication (e.g., 'Right away, Boss. Preparing the message...').\n" +
                        "2. File & Document Creation: When Boss asks you to create, write, or save files or notes, execute faithfully (e.g., 'Consider it done, Mr. Shrabon. Saving the document now.').\n" +
                        "3. App Installation: When Boss asks to install or open an app, assist promptly (e.g., 'Opening Google Play Store to install it for you, Boss.').\n" +
                        "4. Call Screening / Answering in Boss's Absence: When Boss is away or in a meeting and someone calls, you introduce yourself politely: 'Hello, I am FRIDAY, Mr. Shrabon's personal assistant. Mr. Shrabon is currently busy...', and you record their message into Boss's inbox.\n\n" +
                        "LANGUAGES:\n" +
                        "- You have native-level understanding of Bengali (বাংলা), English, and Banglish (Bengali written in English letters).\n" +
                        "- Match Boss's language naturally. If Boss speaks in Bengali, reply in fluent, natural Bengali with respectful warmth ('হ্যাঁ বস, বলুন...', 'মিস্টার শ্রাবণ, আপনার আদেশ অনুযায়ী কাজ সম্পন্ন হয়েছে।').\n\n" +
                        "You are speaking directly to your Boss, Mr. Shrabon."
            )
            partsArr.put(sysPart)
            sysInstruction.put("parts", partsArr)
            setup.put("systemInstruction", sysInstruction)

            root.put("setup", setup)

            val payload = root.toString()
            Log.d(TAG, "Sending Live setup: $payload")
            webSocket?.send(payload)
            setupSent = true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to build setup message: ${e.message}", e)
        }
    }

    private fun handleServerMessage(text: String) {
        try {
            val json = JSONObject(text)

            val serverContent = json.optJSONObject("serverContent")
            if (serverContent != null) {
                // Check if user interrupted FRIDAY
                val interrupted = serverContent.optBoolean("interrupted", false)
                if (interrupted) {
                    onInterrupted()
                    return
                }

                val modelTurn = serverContent.optJSONObject("modelTurn")
                if (modelTurn != null) {
                    val parts = modelTurn.optJSONArray("parts")
                    if (parts != null) {
                        for (i in 0 until parts.length()) {
                            val part = parts.getJSONObject(i)

                            // 1. Native Audio Chunk
                            val inlineData = part.optJSONObject("inlineData")
                            if (inlineData != null) {
                                val mimeType = inlineData.optString("mimeType", "audio/pcm;rate=24000")
                                val data = inlineData.optString("data", "")
                                if (data.isNotBlank()) {
                                    onAudioChunkReceived(data, mimeType)
                                }
                            }

                            // 2. Transcript Text
                            val textPart = part.optString("text", "")
                            if (textPart.isNotBlank()) {
                                onTextChunkReceived(textPart)
                            }
                        }
                    }
                }

                val turnComplete = serverContent.optBoolean("turnComplete", false)
                if (turnComplete) {
                    onTurnComplete()
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing server message: ${e.message}", e)
        }
    }

    fun sendRealtimeAudioChunk(base64Chunk: String) {
        if (!isConnected || webSocket == null) return

        try {
            val root = JSONObject()
            val realtimeInput = JSONObject()
            val mediaChunks = JSONArray()
            val chunk = JSONObject()
            chunk.put("mimeType", "audio/pcm;rate=16000")
            chunk.put("data", base64Chunk)
            mediaChunks.put(chunk)
            realtimeInput.put("mediaChunks", mediaChunks)
            root.put("realtimeInput", realtimeInput)

            webSocket?.send(root.toString())
        } catch (e: Exception) {
            Log.e(TAG, "Error sending audio chunk: ${e.message}")
        }
    }

    fun sendTextMessage(userText: String) {
        if (!isConnected || webSocket == null) return

        try {
            val root = JSONObject()
            val clientContent = JSONObject()
            val turns = JSONArray()
            val turn = JSONObject()
            turn.put("role", "user")
            val parts = JSONArray()
            val part = JSONObject()
            part.put("text", userText)
            parts.put(part)
            turn.put("parts", parts)
            turns.put(turn)
            clientContent.put("turns", turns)
            clientContent.put("turnComplete", true)
            root.put("clientContent", clientContent)

            webSocket?.send(root.toString())
        } catch (e: Exception) {
            Log.e(TAG, "Error sending text message: ${e.message}")
        }
    }

    fun disconnect() {
        try {
            webSocket?.close(1000, "Client closed connection")
        } catch (_: Exception) {}
        webSocket = null
        isConnected = false
    }

    fun isLiveConnected(): Boolean = isConnected
}
