package com.friday.ai.audio

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Base64
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sqrt

class LiveAudioRecorder(
    private val context: Context,
    private val onPcmChunkAvailable: (ByteArray, String) -> Unit,
    private val onAmplitudeChanged: (Float) -> Unit,
    private val onSpeechDetected: () -> Unit,
    private val onSpeechEnded: () -> Unit,
    private val onError: (String) -> Unit
) {
    companion object {
        private const val TAG = "LiveAudioRecorder"
        const val SAMPLE_RATE = 16000
        const val CHUNK_DURATION_MS = 100 // 100ms chunks = 1600 samples = 3200 bytes
        const val SAMPLES_PER_CHUNK = SAMPLE_RATE * CHUNK_DURATION_MS / 1000
        const val BYTES_PER_CHUNK = SAMPLES_PER_CHUNK * 2 // 16-bit = 2 bytes per sample

        // VAD parameters
        private const val SPEECH_RMS_THRESHOLD = 900.0 // RMS threshold for voice detection
        private const val SILENCE_TIMEOUT_CHUNKS = 15 // ~1.5s of silence after speech
    }

    private var audioRecord: AudioRecord? = null
    private val scope = CoroutineScope(Dispatchers.IO)
    private var recordJob: Job? = null

    @Volatile
    var isRecording: Boolean = false
        private set

    private var consecutiveSpeechChunks = 0
    private var consecutiveSilenceChunks = 0
    private var hasActiveSpeechSession = false

    @SuppressLint("MissingPermission")
    fun startRecording(): Boolean {
        if (isRecording) return true

        try {
            val minBufferSize = AudioRecord.getMinBufferSize(
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )

            val bufferSize = (minBufferSize * 2).coerceAtLeast(BYTES_PER_CHUNK * 4)

            audioRecord = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferSize
            )

            if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                // Try standard MIC source if VOICE_RECOGNITION fails on certain devices
                audioRecord?.release()
                audioRecord = AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    bufferSize
                )
            }

            if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                onError("Microphone hardware initialization failed.")
                return false
            }

            audioRecord?.startRecording()
            isRecording = true
            consecutiveSpeechChunks = 0
            consecutiveSilenceChunks = 0
            hasActiveSpeechSession = false

            startRecordLoop()
            return true
        } catch (e: SecurityException) {
            Log.e(TAG, "Missing RECORD_AUDIO permission: ${e.message}")
            onError("Microphone permission is required for voice interaction.")
            return false
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start recording: ${e.message}", e)
            onError("Microphone error: ${e.message}")
            return false
        }
    }

    private fun startRecordLoop() {
        recordJob?.cancel()
        recordJob = scope.launch {
            val buffer = ByteArray(BYTES_PER_CHUNK)

            while (isActive && isRecording) {
                val record = audioRecord ?: break
                val readBytes = record.read(buffer, 0, buffer.size)

                if (readBytes > 0) {
                    val pcmChunk = buffer.copyOf(readBytes)
                    val base64Chunk = Base64.encodeToString(pcmChunk, Base64.NO_WRAP)

                    // Calculate RMS amplitude for visualizer & VAD
                    val rms = calculateRms(pcmChunk)
                    val normalizedAmp = ((rms - 200.0) / 6000.0).coerceIn(0.0, 1.0).toFloat()
                    onAmplitudeChanged(normalizedAmp)

                    // Voice Activity Detection (VAD)
                    if (rms > SPEECH_RMS_THRESHOLD) {
                        consecutiveSpeechChunks++
                        consecutiveSilenceChunks = 0

                        if (consecutiveSpeechChunks >= 2) {
                            if (!hasActiveSpeechSession) {
                                hasActiveSpeechSession = true
                                onSpeechDetected()
                            }
                        }
                    } else {
                        if (hasActiveSpeechSession) {
                            consecutiveSilenceChunks++
                            if (consecutiveSilenceChunks >= SILENCE_TIMEOUT_CHUNKS) {
                                hasActiveSpeechSession = false
                                consecutiveSpeechChunks = 0
                                consecutiveSilenceChunks = 0
                                onSpeechEnded()
                            }
                        }
                    }

                    // Emit audio chunk
                    onPcmChunkAvailable(pcmChunk, base64Chunk)
                }
            }
        }
    }

    private fun calculateRms(pcmData: ByteArray): Double {
        val shortBuffer = ByteBuffer.wrap(pcmData)
            .order(ByteOrder.LITTLE_ENDIAN)
            .asShortBuffer()

        var sumSq = 0.0
        val sampleCount = shortBuffer.remaining()
        if (sampleCount <= 0) return 0.0

        for (i in 0 until sampleCount) {
            val sample = shortBuffer.get(i).toDouble()
            sumSq += sample * sample
        }
        return sqrt(sumSq / sampleCount)
    }

    fun stopRecording() {
        isRecording = false
        recordJob?.cancel()
        recordJob = null

        try {
            audioRecord?.let {
                if (it.state == AudioRecord.STATE_INITIALIZED) {
                    it.stop()
                }
                it.release()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping AudioRecord: ${e.message}")
        }
        audioRecord = null
        onAmplitudeChanged(0f)
    }

    fun release() {
        stopRecording()
    }
}
