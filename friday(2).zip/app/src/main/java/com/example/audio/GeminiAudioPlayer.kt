package com.friday.ai.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Base64
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sqrt

class GeminiAudioPlayer(
    private val onPlaybackStarted: () -> Unit,
    private val onPlaybackDone: () -> Unit,
    private val onAmplitudeChanged: (Float) -> Unit,
    private val onError: (String) -> Unit
) {
    companion object {
        private const val TAG = "GeminiAudioPlayer"
        const val DEFAULT_SAMPLE_RATE = 24000
    }

    private var audioTrack: AudioTrack? = null
    private var currentSampleRate = DEFAULT_SAMPLE_RATE
    private var currentVolume = 1.0f

    private val playbackChannel = Channel<ByteArray>(capacity = 100)
    private val scope = CoroutineScope(Dispatchers.Default)
    private var playbackJob: Job? = null

    @Volatile
    var isPlaying: Boolean = false
        private set

    init {
        startPlaybackLoop()
    }

    fun setVolume(volume: Float) {
        currentVolume = volume.coerceIn(0.0f, 1.0f)
        try {
            audioTrack?.setVolume(currentVolume)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to set volume: ${e.message}")
        }
    }

    private fun ensureAudioTrack(sampleRate: Int) {
        if (audioTrack != null && currentSampleRate == sampleRate) {
            return
        }

        releaseAudioTrack()

        try {
            currentSampleRate = sampleRate
            val minBufferSize = AudioTrack.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )

            val bufferSize = (minBufferSize * 2).coerceAtLeast(4096)

            audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build().apply {
                    setVolume(currentVolume)
                }
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing AudioTrack: ${e.message}", e)
            onError("Audio output initialization failed: ${e.message}")
        }
    }

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    private fun startPlaybackLoop() {
        playbackJob?.cancel()
        playbackJob = scope.launch {
            for (audioData in playbackChannel) {
                if (!isActive) break

                if (!isPlaying) {
                    isPlaying = true
                    try {
                        audioTrack?.play()
                    } catch (e: Exception) {
                        Log.w(TAG, "AudioTrack play exception: ${e.message}")
                    }
                    onPlaybackStarted()
                }

                writeAndAnalyze(audioData)

                // Check if queue has drained
                if (playbackChannel.isEmpty) {
                    // Small delay to allow buffer to finish playing
                    kotlinx.coroutines.delay(80)
                    if (playbackChannel.isEmpty && isPlaying) {
                        isPlaying = false
                        onAmplitudeChanged(0f)
                        onPlaybackDone()
                    }
                }
            }
        }
    }

    private fun writeAndAnalyze(pcmData: ByteArray) {
        val track = audioTrack ?: return
        if (pcmData.isEmpty()) return

        // Calculate real-time RMS amplitude for visualizer
        val shortBuffer = ByteBuffer.wrap(pcmData)
            .order(ByteOrder.LITTLE_ENDIAN)
            .asShortBuffer()

        var sumSq = 0.0
        val sampleCount = shortBuffer.remaining()
        if (sampleCount > 0) {
            for (i in 0 until sampleCount) {
                val sample = shortBuffer.get(i).toDouble()
                sumSq += sample * sample
            }
            val rms = sqrt(sumSq / sampleCount)
            // Normalize RMS amplitude (typical speech RMS ranges 500..12000 for 16-bit PCM)
            val normalizedAmp = ((rms - 300.0) / 7500.0).coerceIn(0.0, 1.0).toFloat()
            onAmplitudeChanged(normalizedAmp)
        }

        try {
            track.write(pcmData, 0, pcmData.size)
        } catch (e: Exception) {
            Log.e(TAG, "AudioTrack write error: ${e.message}")
        }
    }

    /**
     * Enqueue base64 encoded PCM audio data or raw PCM bytes.
     */
    fun enqueueBase64Pcm(base64Data: String, mimeType: String = "audio/pcm;rate=24000") {
        try {
            val sampleRate = parseSampleRate(mimeType)
            ensureAudioTrack(sampleRate)

            val pcmBytes = Base64.decode(base64Data, Base64.DEFAULT)
            // Check if audio has a WAV header (44 bytes standard)
            val rawPcm = if (pcmBytes.size > 44 &&
                pcmBytes[0] == 'R'.code.toByte() &&
                pcmBytes[1] == 'I'.code.toByte() &&
                pcmBytes[2] == 'F'.code.toByte() &&
                pcmBytes[3] == 'F'.code.toByte()
            ) {
                pcmBytes.copyOfRange(44, pcmBytes.size)
            } else {
                pcmBytes
            }

            playbackChannel.trySend(rawPcm)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to decode/enqueue audio chunk: ${e.message}")
        }
    }

    fun enqueueRawPcm(pcmBytes: ByteArray, sampleRate: Int = DEFAULT_SAMPLE_RATE) {
        ensureAudioTrack(sampleRate)
        playbackChannel.trySend(pcmBytes)
    }

    private fun parseSampleRate(mimeType: String): Int {
        return try {
            if (mimeType.contains("rate=")) {
                val rateStr = mimeType.substringAfter("rate=").substringBefore(";").substringBefore(" ").trim()
                rateStr.toIntOrNull() ?: DEFAULT_SAMPLE_RATE
            } else if (mimeType.contains("16000")) {
                16000
            } else {
                DEFAULT_SAMPLE_RATE
            }
        } catch (_: Exception) {
            DEFAULT_SAMPLE_RATE
        }
    }

    /**
     * Stop and immediately discard any queued or currently playing audio.
     */
    fun stopAndDiscard() {
        // Drain channel
        while (playbackChannel.tryReceive().isSuccess) {
            // drained
        }

        try {
            audioTrack?.let {
                if (it.playState == AudioTrack.PLAYSTATE_PLAYING) {
                    it.pause()
                    it.flush()
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error pausing AudioTrack: ${e.message}")
        }

        isPlaying = false
        onAmplitudeChanged(0f)
    }

    private fun releaseAudioTrack() {
        try {
            audioTrack?.let {
                it.stop()
                it.release()
            }
        } catch (_: Exception) {}
        audioTrack = null
    }

    fun release() {
        stopAndDiscard()
        playbackJob?.cancel()
        playbackChannel.close()
        releaseAudioTrack()
    }
}
