package com.friday.ai.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class ScreenedCallMessage(
    val id: String = UUID.randomUUID().toString(),
    val callerName: String,
    val callerNumber: String,
    val messageText: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isUrgent: Boolean = false,
    val formattedTime: String = SimpleDateFormat("MMM dd, hh:mm a", Locale.getDefault()).format(Date(timestamp))
)

data class FridayFileRecord(
    val id: String = UUID.randomUUID().toString(),
    val fileName: String,
    val filePath: String,
    val contentPreview: String,
    val sizeBytes: Long,
    val createdAt: Long = System.currentTimeMillis(),
    val formattedTime: String = SimpleDateFormat("MMM dd, hh:mm a", Locale.getDefault()).format(Date(createdAt))
)

sealed class BossActionPayload {
    data class SendMessage(val recipient: String, val messageBody: String) : BossActionPayload()
    data class CreateFile(val fileName: String, val content: String) : BossActionPayload()
    data class InstallApp(val appName: String) : BossActionPayload()
    data class ScreenCall(val callerName: String, val callerMessage: String) : BossActionPayload()
}

class BossActionsRepository(private val context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("friday_boss_actions_prefs", Context.MODE_PRIVATE)

    private val _screenedCalls = MutableStateFlow<List<ScreenedCallMessage>>(emptyList())
    val screenedCalls: StateFlow<List<ScreenedCallMessage>> = _screenedCalls.asStateFlow()

    private val _createdFiles = MutableStateFlow<List<FridayFileRecord>>(emptyList())
    val createdFiles: StateFlow<List<FridayFileRecord>> = _createdFiles.asStateFlow()

    companion object {
        private const val KEY_SCREENED_CALLS = "key_screened_calls"
        private const val KEY_CREATED_FILES = "key_created_files"
    }

    init {
        loadStoredData()
    }

    private fun loadStoredData() {
        // Load Calls
        val callsJson = prefs.getString(KEY_SCREENED_CALLS, null)
        if (!callsJson.isNullOrBlank()) {
            try {
                val array = JSONArray(callsJson)
                val list = mutableListOf<ScreenedCallMessage>()
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    list.add(
                        ScreenedCallMessage(
                            id = obj.optString("id", UUID.randomUUID().toString()),
                            callerName = obj.optString("callerName", "Unknown Caller"),
                            callerNumber = obj.optString("callerNumber", ""),
                            messageText = obj.optString("messageText", ""),
                            timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                            isUrgent = obj.optBoolean("isUrgent", false)
                        )
                    )
                }
                _screenedCalls.value = list
            } catch (_: Exception) {}
        } else {
            // Add initial sample message from FRIDAY
            val sample = ScreenedCallMessage(
                callerName = "John from Tech Team",
                callerNumber = "+880 1711-234567",
                messageText = "Hi Mr. Shrabon, FRIDAY informed me you are in a meeting. Please check the project deploy update when you are free.",
                timestamp = System.currentTimeMillis() - 1000 * 60 * 45,
                isUrgent = false
            )
            _screenedCalls.value = listOf(sample)
            saveCallsToPrefs()
        }

        // Load Files
        val filesJson = prefs.getString(KEY_CREATED_FILES, null)
        if (!filesJson.isNullOrBlank()) {
            try {
                val array = JSONArray(filesJson)
                val list = mutableListOf<FridayFileRecord>()
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    list.add(
                        FridayFileRecord(
                            id = obj.optString("id", UUID.randomUUID().toString()),
                            fileName = obj.optString("fileName", "Note.txt"),
                            filePath = obj.optString("filePath", ""),
                            contentPreview = obj.optString("contentPreview", ""),
                            sizeBytes = obj.optLong("sizeBytes", 0L),
                            createdAt = obj.optLong("createdAt", System.currentTimeMillis())
                        )
                    )
                }
                _createdFiles.value = list
            } catch (_: Exception) {}
        }
    }

    private fun saveCallsToPrefs() {
        val array = JSONArray()
        for (item in _screenedCalls.value) {
            val obj = JSONObject()
            obj.put("id", item.id)
            obj.put("callerName", item.callerName)
            obj.put("callerNumber", item.callerNumber)
            obj.put("messageText", item.messageText)
            obj.put("timestamp", item.timestamp)
            obj.put("isUrgent", item.isUrgent)
            array.put(obj)
        }
        prefs.edit().putString(KEY_SCREENED_CALLS, array.toString()).apply()
    }

    private fun saveFilesToPrefs() {
        val array = JSONArray()
        for (item in _createdFiles.value) {
            val obj = JSONObject()
            obj.put("id", item.id)
            obj.put("fileName", item.fileName)
            obj.put("filePath", item.filePath)
            obj.put("contentPreview", item.contentPreview)
            obj.put("sizeBytes", item.sizeBytes)
            obj.put("createdAt", item.createdAt)
            array.put(obj)
        }
        prefs.edit().putString(KEY_CREATED_FILES, array.toString()).apply()
    }

    fun addScreenedCall(callerName: String, callerNumber: String, messageText: String, isUrgent: Boolean = false): ScreenedCallMessage {
        val newCall = ScreenedCallMessage(
            callerName = callerName.ifBlank { "Unknown Caller" },
            callerNumber = callerNumber,
            messageText = messageText,
            timestamp = System.currentTimeMillis(),
            isUrgent = isUrgent
        )
        val updated = listOf(newCall) + _screenedCalls.value
        _screenedCalls.value = updated
        saveCallsToPrefs()
        return newCall
    }

    fun deleteScreenedCall(id: String) {
        val updated = _screenedCalls.value.filter { it.id != id }
        _screenedCalls.value = updated
        saveCallsToPrefs()
    }

    fun clearAllScreenedCalls() {
        _screenedCalls.value = emptyList()
        saveCallsToPrefs()
    }

    fun recordCreatedFile(fileName: String, filePath: String, content: String, sizeBytes: Long): FridayFileRecord {
        val preview = if (content.length > 120) content.take(120) + "..." else content
        val newFile = FridayFileRecord(
            fileName = fileName,
            filePath = filePath,
            contentPreview = preview,
            sizeBytes = sizeBytes,
            createdAt = System.currentTimeMillis()
        )
        val updated = listOf(newFile) + _createdFiles.value
        _createdFiles.value = updated
        saveFilesToPrefs()
        return newFile
    }

    fun deleteFileRecord(id: String) {
        val record = _createdFiles.value.find { it.id == id }
        if (record != null) {
            try {
                val f = File(record.filePath)
                if (f.exists()) f.delete()
            } catch (_: Exception) {}
        }
        val updated = _createdFiles.value.filter { it.id != id }
        _createdFiles.value = updated
        saveFilesToPrefs()
    }
}
