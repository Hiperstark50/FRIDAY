package com.friday.ai.data

import android.content.Context
import android.content.SharedPreferences
import com.example.BuildConfig

class SecurePreferences(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("friday_secure_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_CUSTOM_GEMINI_API_KEY = "custom_gemini_api_key"
        private const val KEY_SELECTED_MODEL = "selected_model"
        private const val KEY_SELECTED_VOICE = "selected_voice"
        private const val KEY_VOICE_STYLE = "voice_style"
        private const val KEY_VOICE_SPEED = "voice_speed"
        private const val KEY_VOLUME = "volume"
        private const val KEY_AUTO_LISTEN = "auto_listen"
        private const val KEY_TTS_ENABLED = "tts_enabled"

        // Default to Gemini Native Audio / Live model with Leda voice
        const val DEFAULT_MODEL = "gemini-3.1-flash-live-preview"
        const val DEFAULT_VOICE = "Leda"
        const val DEFAULT_VOICE_STYLE = "Natural"
        const val DEFAULT_BOSS_NAME = "Mr. Shrabon"
    }

    private val KEY_BOSS_NAME = "boss_name"
    private val KEY_CALL_SCREENING = "call_screening_enabled"

    fun getBossName(): String {
        return prefs.getString(KEY_BOSS_NAME, DEFAULT_BOSS_NAME) ?: DEFAULT_BOSS_NAME
    }

    fun saveBossName(name: String) {
        prefs.edit().putString(KEY_BOSS_NAME, name.trim()).apply()
    }

    fun isCallScreeningEnabled(): Boolean {
        return prefs.getBoolean(KEY_CALL_SCREENING, true)
    }

    fun saveCallScreeningEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_CALL_SCREENING, enabled).apply()
    }

    fun getEffectiveApiKey(): String {
        val customKey = prefs.getString(KEY_CUSTOM_GEMINI_API_KEY, "")?.trim() ?: ""
        if (customKey.isNotBlank()) {
            return customKey
        }
        val buildKey = try {
            BuildConfig.GEMINI_API_KEY.trim()
        } catch (_: Exception) {
            ""
        }
        if (buildKey.isNotBlank() && buildKey != "MY_GEMINI_API_KEY" && !buildKey.contains("placeholder", ignoreCase = true)) {
            return buildKey
        }
        return ""
    }

    fun hasApiKey(): Boolean {
        return getEffectiveApiKey().isNotBlank()
    }

    fun getSavedCustomApiKey(): String {
        return prefs.getString(KEY_CUSTOM_GEMINI_API_KEY, "") ?: ""
    }

    fun saveCustomApiKey(key: String) {
        prefs.edit().putString(KEY_CUSTOM_GEMINI_API_KEY, key.trim()).apply()
    }

    fun getMaskedApiKey(): String {
        val key = getEffectiveApiKey()
        if (key.isBlank()) return "Not Configured"
        if (key.length <= 8) return "••••••••"
        val prefix = key.take(4)
        val suffix = key.takeLast(4)
        return "$prefix••••••••••$suffix"
    }

    fun getSelectedModel(): String {
        return prefs.getString(KEY_SELECTED_MODEL, DEFAULT_MODEL) ?: DEFAULT_MODEL
    }

    fun saveSelectedModel(model: String) {
        prefs.edit().putString(KEY_SELECTED_MODEL, model).apply()
    }

    fun getSelectedVoice(): String {
        val saved = prefs.getString(KEY_SELECTED_VOICE, DEFAULT_VOICE) ?: DEFAULT_VOICE
        // Migrate legacy TTS voice names if present
        return if (saved.contains("Neural") || saved.contains("TTS") || saved.isBlank()) {
            DEFAULT_VOICE
        } else {
            saved
        }
    }

    fun saveSelectedVoice(voice: String) {
        prefs.edit().putString(KEY_SELECTED_VOICE, voice).apply()
    }

    fun getVoiceStyle(): String {
        return prefs.getString(KEY_VOICE_STYLE, DEFAULT_VOICE_STYLE) ?: DEFAULT_VOICE_STYLE
    }

    fun saveVoiceStyle(style: String) {
        prefs.edit().putString(KEY_VOICE_STYLE, style).apply()
    }

    fun getVoiceSpeed(): Float {
        return prefs.getFloat(KEY_VOICE_SPEED, 1.0f)
    }

    fun saveVoiceSpeed(speed: Float) {
        prefs.edit().putFloat(KEY_VOICE_SPEED, speed.coerceIn(0.5f, 2.0f)).apply()
    }

    fun getVolume(): Float {
        return prefs.getFloat(KEY_VOLUME, 1.0f)
    }

    fun saveVolume(volume: Float) {
        prefs.edit().putFloat(KEY_VOLUME, volume.coerceIn(0.0f, 1.0f)).apply()
    }

    fun isAutoListenEnabled(): Boolean {
        return prefs.getBoolean(KEY_AUTO_LISTEN, false)
    }

    fun saveAutoListen(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_AUTO_LISTEN, enabled).apply()
    }

    fun isTtsEnabled(): Boolean {
        return prefs.getBoolean(KEY_TTS_ENABLED, true)
    }

    fun saveTtsEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_TTS_ENABLED, enabled).apply()
    }
}
