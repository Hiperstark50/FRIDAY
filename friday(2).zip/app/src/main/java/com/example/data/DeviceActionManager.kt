package com.friday.ai.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import java.io.File

class DeviceActionManager(
    private val context: Context,
    private val bossActionsRepository: BossActionsRepository,
    private val securePreferences: SecurePreferences
) {
    companion object {
        private const val TAG = "DeviceActionManager"
    }

    /**
     * Sends an SMS/Text message via native Android Intent.
     */
    fun openSmsComposer(recipient: String, messageText: String): Boolean {
        return try {
            val cleanRecipient = recipient.replace(Regex("[^0-9+]"), "")
            val intent = if (cleanRecipient.isNotBlank()) {
                Intent(Intent.ACTION_SENDTO).apply {
                    data = Uri.parse("smsto:$cleanRecipient")
                    putExtra("sms_body", messageText)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
            } else {
                Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, messageText)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to launch SMS composer: ${e.message}", e)
            false
        }
    }

    /**
     * Creates a document/text file in the app storage.
     */
    fun createFile(rawFileName: String, content: String): Result<FridayFileRecord> {
        return try {
            val cleanName = rawFileName.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_").let {
                if (it.endsWith(".txt") || it.endsWith(".md") || it.endsWith(".json") || it.endsWith(".doc")) it else "$it.txt"
            }
            val docsDir = File(context.filesDir, "friday_documents")
            if (!docsDir.exists()) {
                docsDir.mkdirs()
            }

            val targetFile = File(docsDir, cleanName)
            targetFile.writeText(content, Charsets.UTF_8)

            val record = bossActionsRepository.recordCreatedFile(
                fileName = cleanName,
                filePath = targetFile.absolutePath,
                content = content,
                sizeBytes = targetFile.length()
            )
            Result.success(record)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to create file: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Installs or searches an app on Google Play Store, or opens if installed.
     */
    fun installOrSearchApp(appName: String): Boolean {
        return try {
            val query = appName.trim()
            val intent = Intent(Intent.ACTION_VIEW).apply {
                data = Uri.parse("https://play.google.com/store/search?q=${Uri.encode(query)}&c=apps")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to open Play Store for $appName: ${e.message}", e)
            false
        }
    }

    /**
     * Generates FRIDAY's executive call answering script in Leda's voice.
     */
    fun getCallAssistantIntro(callerName: String = ""): String {
        val bossName = securePreferences.getBossName()
        return if (callerName.isNotBlank()) {
            "Hello $callerName, I am FRIDAY, $bossName's personal assistant. $bossName is currently occupied and unavailable to take your call. Please state your message, and I will record and deliver it to him immediately."
        } else {
            "Hello, I am FRIDAY, $bossName's personal assistant. $bossName is currently busy and unavailable to answer right now. Please tell me your name and your message, and I will deliver it to $bossName right away."
        }
    }

    fun getCallAssistantIntroBangla(callerName: String = ""): String {
        val bossName = securePreferences.getBossName()
        return if (callerName.isNotBlank()) {
            "হ্যালো $callerName, আমি ফ্রাইডে, $bossName-এর পার্সোনাল অ্যাসিস্ট্যান্ট। $bossName এই মুহূর্তে ব্যস্ত থাকায় কল রিসিভ করতে পারছেন না। আপনি আপনার বার্তাটি বলুন, আমি সরাসরি $bossName-এর কাছে পৌঁছে দেব।"
        } else {
            "হ্যালো, আমি ফ্রাইডে, $bossName-এর পার্সোনাল অ্যাসিস্ট্যান্ট। $bossName এই মুহূর্তে ব্যস্ত আছেন। অনুগ্রহ করে আপনার নাম ও প্রয়োজনীয় বার্তাটি বলুন, আমি ওনার কাছে ইনবক্সে পৌঁছে দেব।"
        }
    }
}
