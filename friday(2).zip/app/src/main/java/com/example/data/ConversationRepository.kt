package com.friday.ai.data

import com.example.state.ConversationMessage
import com.example.state.MessageSender
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class ConversationRepository {
    private val _messages = MutableStateFlow<List<ConversationMessage>>(emptyList())
    val messages: StateFlow<List<ConversationMessage>> = _messages.asStateFlow()

    fun addMessage(sender: MessageSender, text: String): ConversationMessage {
        val message = ConversationMessage(sender = sender, text = text)
        _messages.value = _messages.value + message
        return message
    }

    fun clear() {
        _messages.value = emptyList()
    }

    fun getHistory(): List<ConversationMessage> {
        return _messages.value
    }
}
