package com.friday.ai.state

enum class FridayMode {
    IDLE,
    LISTENING,
    PROCESSING,
    SPEAKING
}

enum class ConnectionStatus {
    ONLINE,
    CONNECTING,
    OFFLINE
}

data class ConversationMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val sender: MessageSender,
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

enum class MessageSender {
    USER,
    FRIDAY
}

data class FridayUiState(
    val mode: FridayMode = FridayMode.IDLE,
    val statusText: String = "FRIDAY • ONLINE",
    val connectionStatus: ConnectionStatus = ConnectionStatus.ONLINE,
    val audioAmplitude: Float = 0f, // 0.0f to 1.0f, real-time PCM amplitude
    val currentInputText: String = "",
    val lastRecognizedSpeech: String = "",
    val lastFridayResponse: String = "",
    val errorMessage: String? = null,
    val isTextModeOpen: Boolean = false,
    val isSettingsOpen: Boolean = false,
    val isInitializing: Boolean = true,
    val apiKeyConfigured: Boolean = false,
    val maskedApiKey: String = "",
    val customApiKey: String = "",
    val selectedModel: String = "gemini-3.1-flash-live-preview",
    val selectedVoice: String = "Aoede",
    val voiceStyle: String = "Natural",
    val voiceSpeed: Float = 1.0f,
    val volume: Float = 1.0f,
    val isAutoListenEnabled: Boolean = false,
    val isTtsEnabled: Boolean = true,
    val conversationHistory: List<ConversationMessage> = emptyList(),
    val isTestingConnection: Boolean = false,
    val connectionTestResult: String? = null,
    val isLiveConnected: Boolean = false,
    val isApiKeyDialogOpen: Boolean = false,
    val bossName: String = "Mr. Shrabon",
    val isBossHubOpen: Boolean = false,
    val isCallScreeningActive: Boolean = false,
    val isSimulatingCall: Boolean = false,
    val screenedCalls: List<com.example.data.ScreenedCallMessage> = emptyList(),
    val createdFiles: List<com.example.data.FridayFileRecord> = emptyList(),
    val lastActionToast: String? = null
)
