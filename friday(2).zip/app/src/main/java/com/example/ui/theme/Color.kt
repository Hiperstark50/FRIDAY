package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val FridayCyan = Color(0xFF00E5FF)
val FridayCyanLight = Color(0xFF80F2FF)
val FridayCyanDark = Color(0xFF005B66)
val FridayCyanGlow = Color(0x3300E5FF)

val FridayAmber = Color(0xFFFFB300)
val FridayAmberGlow = Color(0x33FFB300)

val FridayEmerald = Color(0xFF00E676)
val FridayCrimson = Color(0xFFFF3D57)

val FridayBgDark = Color(0xFF030712)
val FridayScrimDark = Color(0xD9030712)
val FridayGlassSurface = Color(0xCC09121F)
val FridayGlassSurfaceLight = Color(0x8013233A)

val FridayBorderGlow = Color(0x6600E5FF)
val FridayBorderDim = Color(0x2B00E5FF)

val FridayTextPrimary = Color(0xFFEDF8FD)
val FridayTextSecondary = Color(0xFF8BA6BC)
val FridayTextDim = Color(0xFF4A657A)
