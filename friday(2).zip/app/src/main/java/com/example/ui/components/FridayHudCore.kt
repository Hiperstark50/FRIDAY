package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.state.FridayMode
import com.example.ui.theme.FridayAmber
import com.example.ui.theme.FridayCyan
import com.example.ui.theme.FridayCyanLight
import com.example.ui.theme.FridayEmerald
import kotlin.math.cos
import kotlin.math.sin

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FridayHudCore(
    mode: FridayMode,
    audioAmplitude: Float,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 190.dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "hud_infinite")

    // Subtle idle breathing
    val idlePulse by infiniteTransition.animateFloat(
        initialValue = 0.88f,
        targetValue = 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(2800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "idle_pulse"
    )

    // Smooth slow rotation for processing or active modes
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (mode == FridayMode.PROCESSING) 3000 else 18000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "core_rotation"
    )

    // Wave resonance for speaking/listening
    val wavePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 6.283f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave_phase"
    )

    val interactionSource = remember { MutableInteractionSource() }

    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .combinedClickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick,
                onLongClick = onLongClick
            )
            .testTag("central_friday_core"),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val centerOffset = Offset(this.size.width / 2f, this.size.height / 2f)
            val baseRadius = (this.size.minDimension / 2f) * 0.72f

            // Dynamic color selection based on state
            val activeColor = when (mode) {
                FridayMode.IDLE -> FridayCyan
                FridayMode.LISTENING -> FridayAmber
                FridayMode.PROCESSING -> FridayCyanLight
                FridayMode.SPEAKING -> FridayEmerald
            }

            val amplitude = audioAmplitude.coerceIn(0f, 1f)

            when (mode) {
                FridayMode.IDLE -> {
                    // Subtle breathing energy ring that aligns seamlessly with existing HUD circle
                    val currentRadius = baseRadius * idlePulse
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                activeColor.copy(alpha = 0.12f),
                                activeColor.copy(alpha = 0.04f),
                                Color.Transparent
                            ),
                            center = centerOffset,
                            radius = currentRadius * 1.15f
                        ),
                        radius = currentRadius * 1.15f,
                        center = centerOffset
                    )

                    // Delicate dashed alignment trace
                    drawCircle(
                        color = activeColor.copy(alpha = 0.35f * idlePulse),
                        radius = currentRadius,
                        center = centerOffset,
                        style = Stroke(
                            width = 1.2.dp.toPx(),
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 14f), 0f)
                        )
                    )
                }

                FridayMode.LISTENING -> {
                    // Responds directly to real microphone volume / amplitude!
                    val reactiveRadius = baseRadius * (1.0f + amplitude * 0.32f)
                    val glowRadius = baseRadius * (1.1f + amplitude * 0.45f)

                    // Audio reactive outer glow
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                activeColor.copy(alpha = 0.25f + amplitude * 0.45f),
                                activeColor.copy(alpha = 0.08f + amplitude * 0.2f),
                                Color.Transparent
                            ),
                            center = centerOffset,
                            radius = glowRadius
                        ),
                        radius = glowRadius,
                        center = centerOffset
                    )

                    // Concentric voice ripples
                    val rippleCount = 3
                    for (i in 1..rippleCount) {
                        val r = baseRadius * (0.85f + (i * 0.12f) + (amplitude * 0.18f))
                        val alpha = (0.7f - (i * 0.18f) + (amplitude * 0.3f)).coerceIn(0.15f, 0.95f)
                        drawCircle(
                            color = activeColor.copy(alpha = alpha),
                            radius = r,
                            center = centerOffset,
                            style = Stroke(
                                width = (1.5f + amplitude * 2.5f).dp.toPx(),
                                pathEffect = PathEffect.dashPathEffect(
                                    floatArrayOf(16f * i, 12f + (amplitude * 10f)),
                                    rotationAngle * (if (i % 2 == 0) 1f else -1f)
                                )
                            )
                        )
                    }

                    // 8 radial audio frequency node dots
                    val dotCount = 8
                    for (i in 0 until dotCount) {
                        val angleRad = Math.toRadians((i * (360.0 / dotCount) + rotationAngle)).toFloat()
                        val dist = baseRadius * (1.02f + amplitude * 0.2f)
                        val dotX = centerOffset.x + dist * cos(angleRad)
                        val dotY = centerOffset.y + dist * sin(angleRad)
                        drawCircle(
                            color = activeColor.copy(alpha = 0.8f + amplitude * 0.2f),
                            radius = (2.5f + amplitude * 3.5f).dp.toPx(),
                            center = Offset(dotX, dotY)
                        )
                    }
                }

                FridayMode.PROCESSING -> {
                    // Elegant holographic energy vortex
                    val procRadius = baseRadius * 1.02f

                    // Subtle radial core
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                activeColor.copy(alpha = 0.22f),
                                activeColor.copy(alpha = 0.05f),
                                Color.Transparent
                            ),
                            center = centerOffset,
                            radius = procRadius * 1.2f
                        ),
                        radius = procRadius * 1.2f,
                        center = centerOffset
                    )

                    // Orbiting dynamic arc pulses
                    drawArc(
                        color = activeColor.copy(alpha = 0.85f),
                        startAngle = rotationAngle,
                        sweepAngle = 75f,
                        useCenter = false,
                        topLeft = Offset(centerOffset.x - procRadius, centerOffset.y - procRadius),
                        size = androidx.compose.ui.geometry.Size(procRadius * 2, procRadius * 2),
                        style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
                    )

                    drawArc(
                        color = activeColor.copy(alpha = 0.55f),
                        startAngle = rotationAngle + 180f,
                        sweepAngle = 55f,
                        useCenter = false,
                        topLeft = Offset(centerOffset.x - procRadius * 0.88f, centerOffset.y - procRadius * 0.88f),
                        size = androidx.compose.ui.geometry.Size(procRadius * 1.76f, procRadius * 1.76f),
                        style = Stroke(width = 1.6.dp.toPx(), cap = StrokeCap.Round)
                    )
                }

                FridayMode.SPEAKING -> {
                    // Reacts smoothly to FRIDAY's real voice speech amplitude
                    val speakRadius = baseRadius * (0.95f + amplitude * 0.28f)
                    val glowRadius = baseRadius * (1.15f + amplitude * 0.4f)

                    // Resonant voice glow
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                activeColor.copy(alpha = 0.22f + amplitude * 0.4f),
                                activeColor.copy(alpha = 0.06f + amplitude * 0.15f),
                                Color.Transparent
                            ),
                            center = centerOffset,
                            radius = glowRadius
                        ),
                        radius = glowRadius,
                        center = centerOffset
                    )

                    // Concentric holographic harmonic rings
                    val harmonicCount = 4
                    for (i in 1..harmonicCount) {
                        val hRadius = baseRadius * (0.8f + (i * 0.09f) + (amplitude * 0.16f))
                        val waveOffset = sin(wavePhase + i).toFloat() * 4f * amplitude
                        val alpha = (0.8f - (i * 0.14f) + (amplitude * 0.25f)).coerceIn(0.15f, 0.95f)

                        drawCircle(
                            color = activeColor.copy(alpha = alpha),
                            radius = hRadius + waveOffset,
                            center = centerOffset,
                            style = Stroke(
                                width = (1.2f + amplitude * 2.0f).dp.toPx(),
                                pathEffect = PathEffect.dashPathEffect(
                                    floatArrayOf(14f, 10f + (amplitude * 8f)),
                                    (rotationAngle * (if (i % 2 == 0) 0.5f else -0.5f))
                                )
                            )
                        )
                    }

                    // 12 harmonic audio nodes on circumference
                    val nodeCount = 12
                    for (i in 0 until nodeCount) {
                        val angleRad = Math.toRadians((i * (360.0 / nodeCount) + (rotationAngle * 0.4))).toFloat()
                        val nodeDist = speakRadius * (1.0f + (sin(wavePhase + i).toFloat() * 0.06f * amplitude))
                        val nodeX = centerOffset.x + nodeDist * cos(angleRad)
                        val nodeY = centerOffset.y + nodeDist * sin(angleRad)
                        drawCircle(
                            color = activeColor.copy(alpha = 0.75f + amplitude * 0.25f),
                            radius = (2.0f + amplitude * 3.0f).dp.toPx(),
                            center = Offset(nodeX, nodeY)
                        )
                    }
                }
            }
        }
    }
}
