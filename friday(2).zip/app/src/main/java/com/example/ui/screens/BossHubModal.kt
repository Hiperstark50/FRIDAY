package com.friday.ai.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.PhoneCallback
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.GetApp
import androidx.compose.material.icons.filled.Mail
import androidx.compose.material.icons.filled.PhoneInTalk
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ElevatedButton
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

import com.friday.ai.data.FridayFileRecord
import com.friday.ai.data.ScreenedCallMessage

import com.friday.ai.ui.theme.FridayAmber
import com.friday.ai.ui.theme.FridayBorderDim
import com.friday.ai.ui.theme.FridayBorderGlow
import com.friday.ai.ui.theme.FridayCyan
import com.friday.ai.ui.theme.FridayCyanLight
import com.friday.ai.ui.theme.FridayEmerald
import com.friday.ai.ui.theme.FridayGlassSurface
import com.friday.ai.ui.theme.FridayScrimDark
import com.friday.ai.ui.theme.FridayTextDim
import com.friday.ai.ui.theme.FridayTextPrimary
import com.friday.ai.ui.theme.FridayTextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BossHubModal(
    bossName: String,
    isCallScreeningActive: Boolean,
    isSimulatingCall: Boolean,
    screenedCalls: List<ScreenedCallMessage>,
    createdFiles: List<FridayFileRecord>,
    onSaveBossName: (String) -> Unit,
    onToggleCallScreening: (Boolean) -> Unit,
    onSimulateCall: () -> Unit,
    onQuickSendSms: (recipient: String, message: String) -> Unit,
    onQuickCreateFile: (fileName: String, content: String) -> Unit,
    onQuickInstallApp: (appName: String) -> Unit,
    onDeleteScreenedCall: (id: String) -> Unit,
    onDeleteFile: (id: String) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var isEditingName by remember { mutableStateOf(false) }
    var nameInput by remember { mutableStateOf(bossName) }

    // Quick SMS state
    var smsRecipient by remember { mutableStateOf("") }
    var smsMessage by remember { mutableStateOf("") }

    // Quick File state
    var newFileName by remember { mutableStateOf("") }
    var newFileContent by remember { mutableStateOf("") }

    // Quick App state
    var appNameInput by remember { mutableStateOf("") }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(FridayScrimDark)
            .clickable(enabled = false) {}
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            // Header Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(FridayCyan.copy(alpha = 0.15f))
                            .border(1.dp, FridayCyan, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = "Boss Hub",
                            tint = FridayCyan,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "BOSS EXECUTIVE HUB",
                            color = FridayCyanLight,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "FRIDAY • Personal Assistant Protocol",
                            color = FridayTextDim,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                IconButton(
                    onClick = onClose,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(FridayGlassSurface)
                        .border(1.dp, FridayBorderDim, CircleShape)
                        .testTag("close_boss_hub_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = FridayTextPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // Boss Identity Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(FridayGlassSurface)
                    .border(1.dp, FridayBorderGlow, RoundedCornerShape(12.dp))
                    .padding(14.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "BOSS IDENTITY",
                                color = FridayAmber,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                letterSpacing = 1.sp
                            )
                            if (isEditingName) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(top = 4.dp)
                                ) {
                                    OutlinedTextField(
                                        value = nameInput,
                                        onValueChange = { nameInput = it },
                                        singleLine = true,
                                        modifier = Modifier.width(180.dp),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = FridayCyan,
                                            unfocusedBorderColor = FridayBorderDim,
                                            focusedTextColor = FridayTextPrimary,
                                            unfocusedTextColor = FridayTextPrimary
                                        )
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    ElevatedButton(
                                        onClick = {
                                            onSaveBossName(nameInput)
                                            isEditingName = false
                                        },
                                        colors = ButtonDefaults.elevatedButtonColors(containerColor = FridayCyan)
                                    ) {
                                        Text("Save", color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            } else {
                                Text(
                                    text = bossName,
                                    color = FridayTextPrimary,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }

                        if (!isEditingName) {
                            IconButton(
                                onClick = { isEditingName = true },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "Edit Boss Name",
                                    tint = FridayCyan,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "FRIDAY recognizes you as Boss. Voice active: Leda (Warm & Human Persona).",
                        color = FridayTextSecondary,
                        fontSize = 11.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Navigation Tabs (Screened Calls, Vault, Quick Actions)
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = FridayGlassSurface,
                contentColor = FridayCyan,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = FridayCyan
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, FridayBorderDim, RoundedCornerShape(8.dp))
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.AutoMirrored.Filled.PhoneCallback, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Calls (${screenedCalls.size})", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Description, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Files (${createdFiles.size})", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Actions", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Tab Content
            when (selectedTab) {
                0 -> {
                    // Screened Calls Tab
                    Column(modifier = Modifier.fillMaxSize()) {
                        // Call Screening status & Simulate button
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(FridayGlassSurface)
                                .border(1.dp, FridayBorderDim, RoundedCornerShape(8.dp))
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Auto Call Answering",
                                    color = FridayTextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "FRIDAY answers callers when you are busy",
                                    color = FridayTextDim,
                                    fontSize = 10.sp
                                )
                            }

                            Switch(
                                checked = isCallScreeningActive,
                                onCheckedChange = onToggleCallScreening,
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.Black,
                                    checkedTrackColor = FridayCyan,
                                    uncheckedThumbColor = FridayTextDim,
                                    uncheckedTrackColor = FridayBorderDim
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Test screening simulator button
                        ElevatedButton(
                            onClick = onSimulateCall,
                            enabled = !isSimulatingCall,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("simulate_call_screening_button"),
                            colors = ButtonDefaults.elevatedButtonColors(
                                containerColor = if (isSimulatingCall) FridayAmber.copy(alpha = 0.2f) else FridayCyan.copy(alpha = 0.2f)
                            ),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(
                                imageVector = if (isSimulatingCall) Icons.Default.PhoneInTalk else Icons.Default.Call,
                                contentDescription = null,
                                tint = if (isSimulatingCall) FridayAmber else FridayCyan,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isSimulatingCall) "FRIDAY SCREENING IN PROGRESS..." else "TEST CALL SCREENING (LEDA VOICE)",
                                color = if (isSimulatingCall) FridayAmber else FridayCyanLight,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        if (screenedCalls.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "No screened calls yet.\nWhen callers reach out in your absence, FRIDAY logs them here.",
                                    color = FridayTextDim,
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace,
                                    lineHeight = 18.sp
                                )
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(screenedCalls, key = { it.id }) { call ->
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(FridayGlassSurface)
                                            .border(1.dp, FridayBorderDim, RoundedCornerShape(8.dp))
                                            .padding(12.dp)
                                    ) {
                                        Column {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Column {
                                                    Text(
                                                        text = call.callerName,
                                                        color = FridayCyanLight,
                                                        fontSize = 14.sp,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                    Text(
                                                        text = "${call.callerNumber} • ${call.formattedTime}",
                                                        color = FridayTextDim,
                                                        fontSize = 10.sp,
                                                        fontFamily = FontFamily.Monospace
                                                    )
                                                }
                                                IconButton(
                                                    onClick = { onDeleteScreenedCall(call.id) },
                                                    modifier = Modifier.size(24.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Delete,
                                                        contentDescription = "Delete",
                                                        tint = FridayTextDim,
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                }
                                            }
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text(
                                                text = "\"${call.messageText}\"",
                                                color = FridayTextPrimary,
                                                fontSize = 12.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                1 -> {
                    // Files Tab
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                    ) {
                        // Quick create note form
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(FridayGlassSurface)
                                .border(1.dp, FridayBorderDim, RoundedCornerShape(8.dp))
                                .padding(12.dp)
                        ) {
                            Column {
                                Text(
                                    text = "CREATE NEW NOTE / FILE",
                                    color = FridayCyan,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                OutlinedTextField(
                                    value = newFileName,
                                    onValueChange = { newFileName = it },
                                    placeholder = { Text("File name (e.g. project_plan.txt)", color = FridayTextDim, fontSize = 12.sp) },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = FridayCyan,
                                        unfocusedBorderColor = FridayBorderDim,
                                        focusedTextColor = FridayTextPrimary,
                                        unfocusedTextColor = FridayTextPrimary
                                    )
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                OutlinedTextField(
                                    value = newFileContent,
                                    onValueChange = { newFileContent = it },
                                    placeholder = { Text("Enter document notes...", color = FridayTextDim, fontSize = 12.sp) },
                                    minLines = 2,
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = FridayCyan,
                                        unfocusedBorderColor = FridayBorderDim,
                                        focusedTextColor = FridayTextPrimary,
                                        unfocusedTextColor = FridayTextPrimary
                                    )
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                ElevatedButton(
                                    onClick = {
                                        if (newFileName.isNotBlank() && newFileContent.isNotBlank()) {
                                            onQuickCreateFile(newFileName, newFileContent)
                                            newFileName = ""
                                            newFileContent = ""
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.elevatedButtonColors(containerColor = FridayCyan)
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("CREATE FILE FOR BOSS", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "CREATED FILES VAULT",
                            color = FridayTextDim,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        if (createdFiles.isEmpty()) {
                            Text(
                                text = "No files created yet.\nSay 'Create file note.txt with content...' to FRIDAY anytime.",
                                color = FridayTextDim,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        } else {
                            createdFiles.forEach { file ->
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(FridayGlassSurface)
                                        .border(1.dp, FridayBorderDim, RoundedCornerShape(8.dp))
                                        .padding(12.dp)
                                ) {
                                    Column {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Column {
                                                Text(
                                                    text = file.fileName,
                                                    color = FridayCyanLight,
                                                    fontSize = 14.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    fontFamily = FontFamily.Monospace
                                                )
                                                Text(
                                                    text = "${file.sizeBytes} B • ${file.formattedTime}",
                                                    color = FridayTextDim,
                                                    fontSize = 10.sp
                                                )
                                            }
                                            IconButton(
                                                onClick = { onDeleteFile(file.id) },
                                                modifier = Modifier.size(24.dp)
                                            ) {
                                                Icon(Icons.Default.Delete, contentDescription = null, tint = FridayTextDim, modifier = Modifier.size(16.dp))
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = file.contentPreview,
                                            color = FridayTextPrimary,
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                2 -> {
                    // Actions Tab (Quick SMS, Install App)
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                    ) {
                        // Quick SMS Section
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(FridayGlassSurface)
                                .border(1.dp, FridayBorderDim, RoundedCornerShape(8.dp))
                                .padding(12.dp)
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Mail, contentDescription = null, tint = FridayCyan, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "SEND MESSAGE / SMS ON BOSS ORDER",
                                        color = FridayCyan,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                OutlinedTextField(
                                    value = smsRecipient,
                                    onValueChange = { smsRecipient = it },
                                    placeholder = { Text("Recipient (Phone number or Contact)", color = FridayTextDim, fontSize = 12.sp) },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = FridayCyan,
                                        unfocusedBorderColor = FridayBorderDim,
                                        focusedTextColor = FridayTextPrimary,
                                        unfocusedTextColor = FridayTextPrimary
                                    )
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                OutlinedTextField(
                                    value = smsMessage,
                                    onValueChange = { smsMessage = it },
                                    placeholder = { Text("Message text...", color = FridayTextDim, fontSize = 12.sp) },
                                    minLines = 2,
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = FridayCyan,
                                        unfocusedBorderColor = FridayBorderDim,
                                        focusedTextColor = FridayTextPrimary,
                                        unfocusedTextColor = FridayTextPrimary
                                    )
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                ElevatedButton(
                                    onClick = {
                                        if (smsMessage.isNotBlank()) {
                                            onQuickSendSms(smsRecipient, smsMessage)
                                            smsRecipient = ""
                                            smsMessage = ""
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.elevatedButtonColors(containerColor = FridayCyan)
                                ) {
                                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("OPEN SMS COMPOSER", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Quick App Install Section
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(FridayGlassSurface)
                                .border(1.dp, FridayBorderDim, RoundedCornerShape(8.dp))
                                .padding(12.dp)
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.GetApp, contentDescription = null, tint = FridayAmber, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "INSTALL APPS VIA GOOGLE PLAY",
                                        color = FridayAmber,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                OutlinedTextField(
                                    value = appNameInput,
                                    onValueChange = { appNameInput = it },
                                    placeholder = { Text("App name (e.g. WhatsApp, Spotify)", color = FridayTextDim, fontSize = 12.sp) },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = FridayAmber,
                                        unfocusedBorderColor = FridayBorderDim,
                                        focusedTextColor = FridayTextPrimary,
                                        unfocusedTextColor = FridayTextPrimary
                                    )
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                ElevatedButton(
                                    onClick = {
                                        if (appNameInput.isNotBlank()) {
                                            onQuickInstallApp(appNameInput)
                                            appNameInput = ""
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.elevatedButtonColors(containerColor = FridayAmber)
                                ) {
                                    Icon(Icons.Default.GetApp, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("SEARCH & INSTALL ON PLAY STORE", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
