package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.FridayAmber
import com.example.ui.theme.FridayBorderDim
import com.example.ui.theme.FridayBorderGlow
import com.example.ui.theme.FridayCyan
import com.example.ui.theme.FridayCyanLight
import com.example.ui.theme.FridayEmerald
import com.example.ui.theme.FridayGlassSurface
import com.example.ui.theme.FridayScrimDark
import com.example.ui.theme.FridayTextDim
import com.example.ui.theme.FridayTextPrimary
import com.example.ui.theme.FridayTextSecondary
import java.util.Locale

@Composable
fun SettingsScreen(
    maskedApiKey: String,
    currentCustomApiKey: String,
    selectedModel: String,
    selectedVoice: String,
    voiceStyle: String,
    voiceSpeed: Float,
    volume: Float,
    isAutoListen: Boolean,
    isTtsEnabled: Boolean,
    isTestingConnection: Boolean,
    connectionTestResult: String?,
    onSaveApiKey: (String) -> Unit,
    onSelectModel: (String) -> Unit,
    onSelectVoice: (String) -> Unit,
    onSelectVoiceStyle: (String) -> Unit,
    onChangeVoiceSpeed: (Float) -> Unit,
    onChangeVolume: (Float) -> Unit,
    onToggleAutoListen: (Boolean) -> Unit,
    onToggleTts: (Boolean) -> Unit,
    onTestConnection: () -> Unit,
    onTestVoice: () -> Unit,
    onClearConversation: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    var apiKeyInput by remember { mutableStateOf(currentCustomApiKey) }
    var isEditingKey by remember { mutableStateOf(false) }
    var modelDropdownExpanded by remember { mutableStateOf(false) }
    var voiceDropdownExpanded by remember { mutableStateOf(false) }
    var styleDropdownExpanded by remember { mutableStateOf(false) }

    val availableModels = listOf(
        "gemini-3.1-flash-live-preview" to "Gemini 3.1 Flash Live (Preferred Live Audio)",
        "gemini-2.5-flash-native-audio-preview-12-2025" to "Gemini 2.5 Flash Native Audio",
        "gemini-2.5-flash-preview-tts" to "Gemini 2.5 TTS",
        "gemini-3.5-flash" to "Gemini 3.5 Flash"
    )

    val supportedGeminiVoices = listOf(
        "Leda" to "Leda (Female • Warm, Confident & Loyal Executive Assistant - Default)",
        "Aoede" to "Aoede (Female • Natural & Composed)",
        "Kore" to "Kore (Female • Soothing & Relaxed)",
        "Calliope" to "Calliope (Female • Crisp & Bright)",
        "Nova" to "Nova (Female • Futuristic & Clear)",
        "Fenrir" to "Fenrir (Male • Authoritative & Deep)",
        "Puck" to "Puck (Male • Engaging & Dynamic)",
        "Charon" to "Charon (Male • Deep & Calm)"
    )

    val voiceStyles = listOf(
        "Natural" to "Natural (Warm & Conversational)",
        "Calm" to "Calm (Soothing & Composed)",
        "Professional" to "Professional (Crisp & Executive)"
    )

    val scrollState = rememberScrollState()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(FridayScrimDark)
            .clickable(enabled = false) {}
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding()
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "FRIDAY PROTOCOLS",
                        color = FridayCyanLight,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 2.sp
                    )
                    Text(
                        text = "Gemini Live Native Audio & Voice Configuration",
                        color = FridayTextDim,
                        fontSize = 11.sp
                    )
                }

                IconButton(
                    onClick = onClose,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(FridayGlassSurface)
                        .border(1.dp, FridayBorderDim, CircleShape)
                        .testTag("close_settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close Settings",
                        tint = FridayCyan,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // Scrollable Content
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .verticalScroll(scrollState),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Section 1: API Configuration
                SettingsCard(title = "GEMINI API ACCESS", icon = Icons.Default.Key) {
                    Text("API Authentication Status", color = FridayTextSecondary, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = maskedApiKey,
                        color = if (maskedApiKey.contains("•")) FridayCyan else FridayAmber,
                        fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    if (!isEditingKey) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0x3300E5FF))
                                    .border(1.dp, FridayBorderGlow, RoundedCornerShape(8.dp))
                                    .clickable {
                                        apiKeyInput = currentCustomApiKey
                                        isEditingKey = true
                                    }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (currentCustomApiKey.isBlank()) "RESET / SET KEY" else "UPDATE KEY",
                                    color = FridayCyanLight,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0x3300E676))
                                    .border(1.dp, Color(0x6600E676), RoundedCornerShape(8.dp))
                                    .clickable(enabled = !isTestingConnection) {
                                        onTestConnection()
                                    }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isTestingConnection) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(14.dp),
                                        color = FridayEmerald,
                                        strokeWidth = 2.dp
                                    )
                                } else {
                                    Text(
                                        text = "TEST CONNECTION",
                                        color = FridayEmerald,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    } else {
                        Column {
                            OutlinedTextField(
                                value = apiKeyInput,
                                onValueChange = { apiKeyInput = it },
                                placeholder = { Text("Paste AQ. or AIza... key", color = FridayTextDim, fontSize = 12.sp) },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = FridayTextPrimary,
                                    unfocusedTextColor = FridayTextPrimary,
                                    focusedBorderColor = FridayCyan,
                                    unfocusedBorderColor = FridayBorderDim
                                ),
                                singleLine = true
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Color(0x22FFFFFF))
                                        .clickable { isEditingKey = false }
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text("CANCEL", color = FridayTextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(FridayCyan)
                                        .clickable {
                                            onSaveApiKey(apiKeyInput.trim())
                                            isEditingKey = false
                                        }
                                        .padding(horizontal = 14.dp, vertical = 6.dp)
                                ) {
                                    Text("SAVE KEY", color = Color(0xFF031622), fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                }
                            }
                        }
                    }

                    if (!connectionTestResult.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = connectionTestResult,
                            color = if (connectionTestResult.contains("Operational", ignoreCase = true) || connectionTestResult.contains("ms")) FridayEmerald else FridayAmber,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                // Section 2: Model Selection
                SettingsCard(title = "NATIVE AUDIO MODEL", icon = Icons.Default.SmartToy) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0x44050F1E))
                            .border(1.dp, FridayBorderDim, RoundedCornerShape(8.dp))
                            .clickable { modelDropdownExpanded = true }
                            .padding(horizontal = 12.dp, vertical = 10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = availableModels.find { it.first == selectedModel }?.second ?: selectedModel,
                                color = FridayCyanLight,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text("▼", color = FridayCyan, fontSize = 10.sp)
                        }

                        DropdownMenu(
                            expanded = modelDropdownExpanded,
                            onDismissRequest = { modelDropdownExpanded = false },
                            modifier = Modifier.background(FridayGlassSurface)
                        ) {
                            availableModels.forEach { (modelId, modelLabel) ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = modelLabel,
                                            color = if (modelId == selectedModel) FridayCyan else FridayTextPrimary,
                                            fontSize = 13.sp
                                        )
                                    },
                                    onClick = {
                                        onSelectModel(modelId)
                                        modelDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Section 3: Gemini Prebuilt Voice & Voice Style
                SettingsCard(title = "GEMINI NATIVE FEMALE VOICE", icon = Icons.Default.RecordVoiceOver) {
                    // Prebuilt Voice Dropdown
                    Text("Prebuilt Voice Character", color = FridayTextSecondary, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0x44050F1E))
                            .border(1.dp, FridayBorderDim, RoundedCornerShape(8.dp))
                            .clickable { voiceDropdownExpanded = true }
                            .padding(horizontal = 12.dp, vertical = 10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val label = supportedGeminiVoices.find { it.first.equals(selectedVoice, ignoreCase = true) }?.second
                                ?: selectedVoice
                            Text(
                                text = label,
                                color = FridayCyanLight,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text("▼", color = FridayCyan, fontSize = 10.sp)
                        }

                        DropdownMenu(
                            expanded = voiceDropdownExpanded,
                            onDismissRequest = { voiceDropdownExpanded = false },
                            modifier = Modifier.background(FridayGlassSurface)
                        ) {
                            supportedGeminiVoices.forEach { (voiceKey, voiceLabel) ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = voiceLabel,
                                            color = if (voiceKey.equals(selectedVoice, ignoreCase = true)) FridayCyan else FridayTextPrimary,
                                            fontSize = 13.sp
                                        )
                                    },
                                    onClick = {
                                        onSelectVoice(voiceKey)
                                        voiceDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Voice Style Dropdown
                    Text("Voice Tone & Persona Style", color = FridayTextSecondary, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0x44050F1E))
                            .border(1.dp, FridayBorderDim, RoundedCornerShape(8.dp))
                            .clickable { styleDropdownExpanded = true }
                            .padding(horizontal = 12.dp, vertical = 10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val styleLabel = voiceStyles.find { it.first.equals(voiceStyle, ignoreCase = true) }?.second
                                ?: voiceStyle
                            Text(
                                text = styleLabel,
                                color = FridayCyanLight,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text("▼", color = FridayCyan, fontSize = 10.sp)
                        }

                        DropdownMenu(
                            expanded = styleDropdownExpanded,
                            onDismissRequest = { styleDropdownExpanded = false },
                            modifier = Modifier.background(FridayGlassSurface)
                        ) {
                            voiceStyles.forEach { (styleKey, label) ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = label,
                                            color = if (styleKey.equals(voiceStyle, ignoreCase = true)) FridayCyan else FridayTextPrimary,
                                            fontSize = 13.sp
                                        )
                                    },
                                    onClick = {
                                        onSelectVoiceStyle(styleKey)
                                        styleDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Speech Speed Selection (Normal / Slightly Slower / Slightly Faster)
                    Text("Speech Cadence", color = FridayTextSecondary, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            0.85f to "Slower (0.85x)",
                            1.0f to "Normal (1.0x)",
                            1.15f to "Faster (1.15x)"
                        ).forEach { (speedVal, label) ->
                            val isSelected = kotlin.math.abs(voiceSpeed - speedVal) < 0.05f
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) Color(0x3300E5FF) else Color(0x22050F1E))
                                    .border(1.dp, if (isSelected) FridayCyan else FridayBorderDim, RoundedCornerShape(8.dp))
                                    .clickable { onChangeVoiceSpeed(speedVal) }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = label,
                                    color = if (isSelected) FridayCyan else FridayTextSecondary,
                                    fontSize = 10.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Volume Slider (0% - 100%)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Output Volume", color = FridayTextSecondary, fontSize = 11.sp)
                        Text("${(volume * 100).toInt()}%", color = FridayCyan, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }
                    Slider(
                        value = volume,
                        onValueChange = onChangeVolume,
                        valueRange = 0.0f..1.0f,
                        colors = SliderDefaults.colors(
                            thumbColor = FridayCyan,
                            activeTrackColor = FridayCyan,
                            inactiveTrackColor = Color(0x3300E5FF)
                        )
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Preview Voice Button (streams real Gemini audio output)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0x2200E5FF))
                            .border(1.dp, FridayBorderDim, RoundedCornerShape(8.dp))
                            .clickable { onTestVoice() }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "PREVIEW NATIVE GEMINI VOICE",
                            color = FridayCyanLight,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                // Section 4: Assistant Protocols
                SettingsCard(title = "ASSISTANT PROTOCOLS", icon = Icons.AutoMirrored.Filled.VolumeUp) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Continuous Auto-Listen", color = FridayTextPrimary, fontSize = 13.sp)
                            Text(
                                "Automatically listen for query after FRIDAY finishes speaking",
                                color = FridayTextDim,
                                fontSize = 11.sp
                            )
                        }
                        Switch(
                            checked = isAutoListen,
                            onCheckedChange = onToggleAutoListen,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = FridayCyan,
                                checkedTrackColor = Color(0x6600E5FF),
                                uncheckedThumbColor = FridayTextDim,
                                uncheckedTrackColor = Color(0x22FFFFFF)
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Gemini Native Audio Playback", color = FridayTextPrimary, fontSize = 13.sp)
                            Text(
                                "Generate and stream real conversational female audio directly from Gemini",
                                color = FridayTextDim,
                                fontSize = 11.sp
                            )
                        }
                        Switch(
                            checked = isTtsEnabled,
                            onCheckedChange = onToggleTts,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = FridayCyan,
                                checkedTrackColor = Color(0x6600E5FF),
                                uncheckedThumbColor = FridayTextDim,
                                uncheckedTrackColor = Color(0x22FFFFFF)
                            )
                        )
                    }
                }

                // Section 5: Session Management
                SettingsCard(title = "SESSION MANAGEMENT", icon = Icons.Default.DeleteOutline) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0x2BFF3D57))
                            .border(1.dp, Color(0x66FF3D57), RoundedCornerShape(8.dp))
                            .clickable { onClearConversation() }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "RESET CONVERSATION HISTORY",
                            color = Color(0xFFFF5252),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                // Section 6: About FRIDAY
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0x33050D1A))
                        .border(1.dp, FridayBorderDim, RoundedCornerShape(12.dp))
                        .padding(14.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "FRIDAY AI v3.0.0",
                            color = FridayCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 1.4.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Gemini Native Audio • Multilingual (Bangla + English)",
                            color = FridayTextDim,
                            fontSize = 10.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun SettingsCard(
    title: String,
    icon: ImageVector,
    content: @Composable () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(FridayGlassSurface)
            .border(1.dp, FridayBorderDim, RoundedCornerShape(14.dp))
            .padding(14.dp)
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = FridayCyan,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = title,
                    color = FridayCyanLight,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.4.sp
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            content()
        }
    }
}
