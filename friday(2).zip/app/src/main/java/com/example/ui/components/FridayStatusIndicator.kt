package com.example.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.state.ConnectionStatus
import com.example.state.FridayMode
import com.example.ui.theme.FridayAmber
import com.example.ui.theme.FridayBorderDim
import com.example.ui.theme.FridayBorderGlow
import com.example.ui.theme.FridayCyan
import com.example.ui.theme.FridayCyanLight
import com.example.ui.theme.FridayEmerald
import com.example.ui.theme.FridayGlassSurfaceLight
import com.example.ui.theme.FridayTextDim
import com.example.ui.theme.FridayTextPrimary
import com.example.ui.theme.FridayTextSecondary

@Composable
fun FridayStatusIndicator(
    statusText: String,
    mode: FridayMode,
    connectionStatus: ConnectionStatus,
    activeSubtitle: String?,
    modifier: Modifier = Modifier
) {
    val indicatorColor = when (mode) {
        FridayMode.IDLE -> when (connectionStatus) {
            ConnectionStatus.ONLINE -> FridayCyan
            ConnectionStatus.CONNECTING -> FridayAmber
            ConnectionStatus.OFFLINE -> Color(0xFFFF5252)
        }
        FridayMode.LISTENING -> FridayAmber
        FridayMode.PROCESSING -> FridayCyanLight
        FridayMode.SPEAKING -> FridayEmerald
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Status Pill
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(FridayGlassSurfaceLight)
                .border(1.dp, FridayBorderGlow.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
                .padding(horizontal = 16.dp, vertical = 6.dp)
                .testTag("status_indicator_pill")
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                // Glowing status dot
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(indicatorColor)
                )

                Spacer(modifier = Modifier.width(8.dp))

                AnimatedContent(
                    targetState = statusText,
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label = "status_text_anim"
                ) { targetText ->
                    Text(
                        text = targetText,
                        color = indicatorColor,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.6.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        // Subtitle / transcription / utterance display
        if (!activeSubtitle.isNullOrBlank()) {
            Spacer(modifier = Modifier.height(10.dp))
            Box(
                modifier = Modifier
                    .widthIn(max = 440.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xCC050D1A))
                    .border(1.dp, FridayBorderDim, RoundedCornerShape(12.dp))
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text(
                    text = activeSubtitle,
                    color = FridayTextPrimary,
                    fontSize = 13.sp,
                    lineHeight = 18.sp,
                    fontFamily = FontFamily.SansSerif,
                    textAlign = TextAlign.Center,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}
