package com.friday.ai.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

import com.friday.ai.R
import com.friday.ai.state.FridayMode
import com.friday.ai.state.FridayUiState
import com.friday.ai.ui.FridayViewModel

import com.friday.ai.ui.components.ApiKeyModal
import com.friday.ai.ui.components.FridayHudCore
import com.friday.ai.ui.components.FridayStatusIndicator

import com.friday.ai.ui.theme.FridayAmber
import com.friday.ai.ui.theme.FridayBgDark
import com.friday.ai.ui.theme.FridayBorderDim
import com.friday.ai.ui.theme.FridayBorderGlow
import com.friday.ai.ui.theme.FridayCyan
import com.friday.ai.ui.theme.FridayCyanLight
import com.friday.ai.ui.theme.FridayEmerald
import com.friday.ai.ui.theme.FridayGlassSurfaceLight
import com.friday.ai.ui.theme.FridayTextDim
import com.friday.ai.ui.theme.FridayTextPrimary

@Composable
fun MainScreen(
    viewModel: FridayViewModel,
    uiState: FridayUiState,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    var hasAudioPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasAudioPermission = isGranted

        if (isGranted) {
            viewModel.startListening()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(FridayBgDark)
    ) {

        Image(
            painter = painterResource(id = R.drawable.hud_bg),
            contentDescription = "FRIDAY Holographic HUD",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(FridayGlassSurfaceLight)
                        .border(
                            1.dp,
                            FridayBorderDim,
                            RoundedCornerShape(10.dp)
                        )
                        .clickable {
                            viewModel.openTextMode()
                        }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .testTag("text_mode_toggle_button")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.ChatBubbleOutline,
                            contentDescription = "Text Mode",
                            tint = FridayCyanLight,
                            modifier = Modifier.size(14.dp)
                        )

                        Spacer(modifier = Modifier.width(6.dp))

                        Text(
                            text = "TEXT",
                            color = FridayCyanLight,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 1.2.sp
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(FridayGlassSurfaceLight)
                        .border(
                            1.dp,
                            FridayBorderGlow,
                            RoundedCornerShape(10.dp)
                        )
                        .clickable {
                            viewModel.openBossHub()
                        }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .testTag("boss_hub_toggle_button")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {

                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = "Boss Hub",
                            tint = FridayAmber,
                            modifier = Modifier.size(14.dp)
                        )

                        Spacer(modifier = Modifier.width(6.dp))

                        Text(
                            text = "BOSS: ${uiState.bossName.uppercase()}",
                            color = FridayAmber,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 1.sp
                        )

                        if (uiState.screenedCalls.isNotEmpty()) {
                            Spacer(modifier = Modifier.width(6.dp))

                            Box(
                                modifier = Modifier
                                    .size(16.dp)
                                    .clip(CircleShape)
                                    .background(FridayCyan),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${uiState.screenedCalls.size}",
                                    color = Color.Black,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                IconButton(
                    onClick = {
                        viewModel.openSettings()
                    },
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(FridayGlassSurfaceLight)
                        .border(
                            1.dp,
                            FridayBorderDim,
                            CircleShape
                        )
                        .testTag("settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Settings",
                        tint = FridayCyan,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            if (!uiState.apiKeyConfigured) {

                Box(
                    modifier = Modifier
                        .padding(
                            horizontal = 20.dp,
                            vertical = 2.dp
                        )
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0x33FFB300))
                        .border(
                            1.dp,
                            Color(0x66FFB300),
                            RoundedCornerShape(10.dp)
                        )
                        .clickable {
                            viewModel.openApiKeyDialog()
                        }
                        .padding(
                            horizontal = 12.dp,
                            vertical = 6.dp
                        )
                        .testTag("api_key_banner")
                ) {

                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {

                        Icon(
                            imageVector = Icons.Default.Key,
                            contentDescription = "Configure Key",
                            tint = FridayAmber,
                            modifier = Modifier.size(14.dp)
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        Text(
                            text = "GEMINI API KEY REQUIRED • TAP TO CONFIGURE",
                            color = FridayAmber,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {

                FridayHudCore(
                    mode = uiState.mode,
                    audioAmplitude = uiState.audioAmplitude,
                    onClick = {

                        if (!hasAudioPermission) {
                            permissionLauncher.launch(
                                Manifest.permission.RECORD_AUDIO
                            )
                        } else {
                            viewModel.onCoreClick(
                                hasAudioPermission
                            )
                        }
                    },
                    onLongClick = {
                        viewModel.onCoreLongClick()
                    },
                    size = 210.dp
                )
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {

                val activeSubtitle = when (uiState.mode) {

                    FridayMode.LISTENING ->
                        uiState.lastRecognizedSpeech.ifBlank {
                            "Speak now..."
                        }

                    FridayMode.PROCESSING ->
                        "Analyzing neural query..."

                    FridayMode.SPEAKING ->
                        uiState.lastFridayResponse

                    FridayMode.IDLE ->
                        null
                }

                FridayStatusIndicator(
                    statusText = uiState.statusText,
                    mode = uiState.mode,
                    connectionStatus = uiState.connectionStatus,
                    activeSubtitle = activeSubtitle
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = when (uiState.mode) {
                        FridayMode.IDLE ->
                            "Tap core to speak • Long press for text"

                        FridayMode.LISTENING ->
                            "Tap core to send immediately"

                        FridayMode.PROCESSING ->
                            "Consulting Gemini..."

                        FridayMode.SPEAKING ->
                            "Tap core to interrupt"
                    },
                    color = FridayTextDim,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp,
                    textAlign = TextAlign.Center
                )
            }
        }

        AnimatedVisibility(
            visible = uiState.errorMessage != null,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(
                    top = 64.dp,
                    start = 20.dp,
                    end = 20.dp
                )
        ) {

            uiState.errorMessage?.let { errorText ->

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xE62A0D15))
                        .border(
                            1.dp,
                            Color(0x99FF3D57),
                            RoundedCornerShape(12.dp)
                        )
                        .padding(
                            horizontal = 16.dp,
                            vertical = 10.dp
                        )
                ) {

                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {

                        Text(
                            text = errorText,
                            color = Color(0xFFFF8A9E),
                            fontSize = 12.sp,
                            modifier = Modifier.weight(1f)
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        IconButton(
                            onClick = {
                                viewModel.dismissError()
                            },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Dismiss Error",
                                tint = Color(0xFFFF8A9E),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = uiState.lastActionToast != null,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(
                    top = 70.dp,
                    start = 20.dp,
                    end = 20.dp
                )
        ) {

            uiState.lastActionToast?.let { toastText ->

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xE60A2218))
                        .border(
                            1.dp,
                            FridayEmerald,
                            RoundedCornerShape(12.dp)
                        )
                        .padding(
                            horizontal = 16.dp,
                            vertical = 10.dp
                        )
                ) {

                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {

                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Success",
                            tint = FridayEmerald,
                            modifier = Modifier.size(16.dp)
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        Text(
                            text = toastText,
                            color = FridayCyanLight,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.weight(1f)
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        IconButton(
                            onClick = {
                                viewModel.clearActionToast()
                            },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Dismiss",
                                tint = FridayTextDim,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }

        if (uiState.isBossHubOpen) {

            BossHubModal(
                bossName = uiState.bossName,
                isCallScreeningActive = uiState.isCallScreeningActive,
                isSimulatingCall = uiState.isSimulatingCall,
                screenedCalls = uiState.screenedCalls,
                createdFiles = uiState.createdFiles,

                onSaveBossName = { name ->
                    viewModel.setBossName(name)
                },

                onToggleCallScreening = { enabled ->
                    viewModel.toggleCallScreening(enabled)
                },

                onSimulateCall = {
                    viewModel.simulateIncomingCall()
                },

                onQuickSendSms = { recipient, msg ->
                    viewModel.quickSendSms(
                        recipient,
                        msg
                    )
                },

                onQuickCreateFile = { name, content ->
                    viewModel.quickCreateFile(
                        name,
                        content
                    )
                },

                onQuickInstallApp = { app ->
                    viewModel.quickInstallApp(app)
                },

                onDeleteScreenedCall = { id ->
                    viewModel.deleteScreenedCall(id)
                },

                onDeleteFile = { id ->
                    viewModel.deleteCreatedFile(id)
                },

                onClose = {
                    viewModel.closeBossHub()
                }
            )
        }

        if (uiState.isTextModeOpen) {

            TextModeScreen(
                conversationHistory = uiState.conversationHistory,

                onSendMessage = { query ->
                    viewModel.sendTextMessage(query)
                },

                onClearHistory = {
                    viewModel.clearConversation()
                },

                onClose = {
                    viewModel.closeTextMode()
                }
            )
        }

        if (uiState.isSettingsOpen) {

            SettingsScreen(
                maskedApiKey = uiState.maskedApiKey,
                currentCustomApiKey = uiState.customApiKey,
                selectedModel = uiState.selectedModel,
                selectedVoice = uiState.selectedVoice,
                voiceStyle = uiState.voiceStyle,
                voiceSpeed = uiState.voiceSpeed,
                volume = uiState.volume,
                isAutoListen = uiState.isAutoListenEnabled,
                isTtsEnabled = uiState.isTtsEnabled,
                isTestingConnection = uiState.isTestingConnection,
                connectionTestResult = uiState.connectionTestResult,

                onSaveApiKey = { newKey ->
                    viewModel.saveApiKey(newKey)
                },

                onSelectModel = { model ->
                    viewModel.selectModel(model)
                },

                onSelectVoice = { voice ->
                    viewModel.selectVoice(voice)
                },

                onSelectVoiceStyle = { style ->
                    viewModel.selectVoiceStyle(style)
                },

                onChangeVoiceSpeed = { speed ->
                    viewModel.setVoiceSpeed(speed)
                },

                onChangeVolume = { vol ->
                    viewModel.setVolume(vol)
                },

                onToggleAutoListen = { enabled ->
                    viewModel.toggleAutoListen(enabled)
                },

                onToggleTts = { enabled ->
                    viewModel.toggleTts(enabled)
                },

                onTestConnection = {
                    viewModel.testConnection()
                },

                onTestVoice = {
                    viewModel.testVoice()
                },

                onClearConversation = {
                    viewModel.clearConversation()
                },

                onClose = {
                    viewModel.closeSettings()
                }
            )
        }

        ApiKeyModal(
            isOpen = uiState.isApiKeyDialogOpen,

            onSaveApiKey = { key ->
                viewModel.saveApiKey(key)
            },

            onDismiss = {
                viewModel.closeApiKeyDialog()
            }
        )
    }
}
