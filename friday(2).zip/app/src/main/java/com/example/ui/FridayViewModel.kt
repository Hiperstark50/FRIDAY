package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.GeminiAudioResult
import com.example.ai.GeminiAudioService
import com.example.ai.GeminiLiveClient
import com.example.ai.GeminiRepository
import com.example.audio.GeminiAudioPlayer
import com.example.audio.LiveAudioRecorder
import com.example.audio.MicrophoneManager
import com.example.data.BossActionsRepository
import com.example.data.DeviceActionManager
import com.example.data.FridayFileRecord
import com.example.data.ScreenedCallMessage
import com.example.data.ConversationRepository
import com.example.data.SecurePreferences
import com.example.state.ConnectionStatus
import com.example.state.ConversationMessage
import com.example.state.FridayMode
import com.example.state.FridayUiState
import com.example.state.MessageSender
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class FridayViewModel(application: Application) : AndroidViewModel(application) {

    private val securePreferences = SecurePreferences(application)
    private val conversationRepository = ConversationRepository()
    private val bossActionsRepository = BossActionsRepository(application)
    private val deviceActionManager = DeviceActionManager(application, bossActionsRepository, securePreferences)
    private val geminiAudioService = GeminiAudioService()
    private val geminiRepository = GeminiRepository(geminiAudioService, securePreferences, conversationRepository)

    private val _uiState = MutableStateFlow(
        FridayUiState(
            apiKeyConfigured = securePreferences.getEffectiveApiKey().isNotBlank(),
            maskedApiKey = securePreferences.getMaskedApiKey(),
            customApiKey = securePreferences.getSavedCustomApiKey(),
            bossName = securePreferences.getBossName(),
            isCallScreeningActive = securePreferences.isCallScreeningEnabled(),
            selectedModel = securePreferences.getSelectedModel(),
            selectedVoice = securePreferences.getSelectedVoice(),
            voiceStyle = securePreferences.getVoiceStyle(),
            voiceSpeed = securePreferences.getVoiceSpeed(),
            volume = securePreferences.getVolume(),
            isAutoListenEnabled = securePreferences.isAutoListenEnabled(),
            isTtsEnabled = securePreferences.isTtsEnabled()
        )
    )
    val uiState: StateFlow<FridayUiState> = _uiState.asStateFlow()

    private var audioPlayer: GeminiAudioPlayer? = null
    private var liveRecorder: LiveAudioRecorder? = null
    private var microphoneManager: MicrophoneManager? = null
    private var geminiLiveClient: GeminiLiveClient? = null

    private var activeAudioJob: Job? = null

    init {
        initAudioPipeline()
        initGeminiLive()
        observeConversation()
        observeBossData()
        performStartupSequence()
    }

    private fun observeBossData() {
        viewModelScope.launch {
            bossActionsRepository.screenedCalls.collect { calls ->
                _uiState.update { it.copy(screenedCalls = calls) }
            }
        }
        viewModelScope.launch {
            bossActionsRepository.createdFiles.collect { files ->
                _uiState.update { it.copy(createdFiles = files) }
            }
        }
    }

    private fun initAudioPipeline() {
        val app = getApplication<Application>()

        // 1. High-fidelity low-latency Gemini PCM Audio Player
        audioPlayer = GeminiAudioPlayer(
            onPlaybackStarted = {
                _uiState.update {
                    it.copy(
                        mode = FridayMode.SPEAKING,
                        statusText = "FRIDAY • SPEAKING"
                    )
                }
            },
            onPlaybackDone = {
                _uiState.update {
                    it.copy(
                        mode = FridayMode.IDLE,
                        statusText = "FRIDAY • ONLINE",
                        audioAmplitude = 0f
                    )
                }
                if (_uiState.value.isAutoListenEnabled) {
                    viewModelScope.launch {
                        delay(400)
                        startListening()
                    }
                }
            },
            onAmplitudeChanged = { amp ->
                if (_uiState.value.mode == FridayMode.SPEAKING) {
                    _uiState.update { it.copy(audioAmplitude = amp) }
                }
            },
            onError = { errMsg ->
                _uiState.update {
                    it.copy(
                        errorMessage = errMsg,
                        mode = FridayMode.IDLE,
                        statusText = "FRIDAY • ONLINE"
                    )
                }
            }
        ).apply {
            setVolume(securePreferences.getVolume())
        }

        // 2. Real-time microphone recorder with Voice Activity Detection (VAD) for instant interruption
        liveRecorder = LiveAudioRecorder(
            context = app,
            onPcmChunkAvailable = { _, base64 ->
                if (geminiLiveClient?.isLiveConnected() == true) {
                    geminiLiveClient?.sendRealtimeAudioChunk(base64)
                }
            },
            onAmplitudeChanged = { amp ->
                if (_uiState.value.mode == FridayMode.LISTENING) {
                    _uiState.update { it.copy(audioAmplitude = amp) }
                }
            },
            onSpeechDetected = {
                // If user starts talking while FRIDAY is speaking -> INTERRUPT IMMEDIATELY
                if (_uiState.value.mode == FridayMode.SPEAKING) {
                    interruptFriday()
                }
            },
            onSpeechEnded = {
                // Silence detected
            },
            onError = { errMsg ->
                _uiState.update { it.copy(errorMessage = errMsg) }
            }
        )

        // 3. Multilingual Speech Recognizer (supports English, Bengali, Banglish)
        microphoneManager = MicrophoneManager(
            context = app,
            onAmplitudeChanged = { amp ->
                if (_uiState.value.mode == FridayMode.LISTENING && liveRecorder?.isRecording != true) {
                    _uiState.update { it.copy(audioAmplitude = amp) }
                }
            },
            onSpeechResult = { recognizedText ->
                _uiState.update {
                    it.copy(
                        lastRecognizedSpeech = recognizedText,
                        statusText = "PROCESSING...",
                        mode = FridayMode.PROCESSING,
                        audioAmplitude = 0f
                    )
                }
                liveRecorder?.stopRecording()
                processUserPrompt(recognizedText)
            },
            onSpeechPartialResult = { partial ->
                _uiState.update { it.copy(lastRecognizedSpeech = partial) }
            },
            onError = { err ->
                liveRecorder?.stopRecording()
                _uiState.update {
                    it.copy(
                        mode = FridayMode.IDLE,
                        statusText = "FRIDAY • ONLINE",
                        audioAmplitude = 0f,
                        errorMessage = err
                    )
                }
            },
            onListeningStateChanged = { listening ->
                if (listening) {
                    _uiState.update {
                        it.copy(
                            mode = FridayMode.LISTENING,
                            statusText = "LISTENING..."
                        )
                    }
                }
            }
        )
    }

    private fun initGeminiLive() {
        geminiLiveClient = GeminiLiveClient(
            onAudioChunkReceived = { base64Audio, mimeType ->
                audioPlayer?.enqueueBase64Pcm(base64Audio, mimeType)
            },
            onTextChunkReceived = { text ->
                _uiState.update {
                    val combined = if (it.lastFridayResponse.isBlank()) text else "${it.lastFridayResponse} $text"
                    it.copy(lastFridayResponse = combined)
                }
            },
            onTurnComplete = {
                val fullResponse = _uiState.value.lastFridayResponse
                if (fullResponse.isNotBlank()) {
                    conversationRepository.addMessage(MessageSender.FRIDAY, fullResponse)
                }
            },
            onInterrupted = {
                interruptFriday()
            },
            onConnected = {
                _uiState.update { it.copy(isLiveConnected = true) }
            },
            onDisconnected = {
                _uiState.update { it.copy(isLiveConnected = false) }
            },
            onError = { errMsg ->
                // Don't show toast for silent background websocket reconnects, but keep state updated
                _uiState.update { it.copy(isLiveConnected = false) }
            }
        )
    }

    private fun observeConversation() {
        viewModelScope.launch {
            conversationRepository.messages.collect { msgs ->
                _uiState.update { it.copy(conversationHistory = msgs) }
            }
        }
    }

    private fun performStartupSequence() {
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isInitializing = true,
                    statusText = "FRIDAY • INITIALIZING...",
                    connectionStatus = ConnectionStatus.CONNECTING
                )
            }
            delay(800)

            val hasKey = securePreferences.getEffectiveApiKey().isNotBlank()
            _uiState.update {
                it.copy(
                    isInitializing = false,
                    apiKeyConfigured = hasKey,
                    isApiKeyDialogOpen = !hasKey,
                    statusText = if (hasKey) "FRIDAY • ONLINE" else "API KEY REQUIRED",
                    connectionStatus = if (hasKey) ConnectionStatus.ONLINE else ConnectionStatus.OFFLINE
                )
            }
        }
    }

    fun onCoreClick(hasAudioPermission: Boolean) {
        if (!_uiState.value.apiKeyConfigured) {
            _uiState.update {
                it.copy(
                    isApiKeyDialogOpen = true,
                    errorMessage = "Gemini API key is required to activate FRIDAY's voice and neural systems."
                )
            }
            return
        }

        when (_uiState.value.mode) {
            FridayMode.IDLE -> {
                if (!hasAudioPermission) {
                    _uiState.update { it.copy(errorMessage = "Microphone permission is required for voice interaction.") }
                    return
                }
                startListening()
            }
            FridayMode.LISTENING -> {
                // Tap to finish speaking immediately and process
                stopListening()
            }
            FridayMode.PROCESSING -> {
                // User can cancel ongoing processing
                activeAudioJob?.cancel()
                _uiState.update {
                    it.copy(
                        mode = FridayMode.IDLE,
                        statusText = "FRIDAY • ONLINE",
                        audioAmplitude = 0f
                    )
                }
            }
            FridayMode.SPEAKING -> {
                // Tap while speaking: interrupt / stop speech immediately
                interruptFriday()
            }
        }
    }

    fun onCoreLongClick() {
        _uiState.update { it.copy(isTextModeOpen = true) }
    }

    fun startListening() {
        interruptFriday()
        _uiState.update {
            it.copy(
                mode = FridayMode.LISTENING,
                statusText = "LISTENING...",
                errorMessage = null,
                lastRecognizedSpeech = ""
            )
        }
        liveRecorder?.startRecording()
        microphoneManager?.startListening()
    }

    fun stopListening() {
        liveRecorder?.stopRecording()
        microphoneManager?.stopListening()
    }

    fun interruptFriday() {
        activeAudioJob?.cancel()
        audioPlayer?.stopAndDiscard()
        _uiState.update {
            it.copy(
                mode = FridayMode.IDLE,
                statusText = "FRIDAY • ONLINE",
                audioAmplitude = 0f
            )
        }
    }

    fun processUserPrompt(prompt: String) {
        if (prompt.isBlank()) {
            _uiState.update {
                it.copy(
                    mode = FridayMode.IDLE,
                    statusText = "FRIDAY • ONLINE"
                )
            }
            return
        }

        conversationRepository.addMessage(MessageSender.USER, prompt)

        // Check if Boss gave a direct command (SMS, File, App install, Call screen)
        checkAndExecuteBossCommand(prompt)

        _uiState.update {
            it.copy(
                mode = FridayMode.PROCESSING,
                statusText = "PROCESSING...",
                lastRecognizedSpeech = prompt,
                lastFridayResponse = ""
            )
        }

        activeAudioJob?.cancel()
        activeAudioJob = viewModelScope.launch(Dispatchers.IO) {
            val result = geminiRepository.askFridayNativeAudio(prompt)

            if (result.isSuccess) {
                val audioResult = result.getOrNull()
                val responseText = audioResult?.transcriptText ?: "Understood, Boss."
                conversationRepository.addMessage(MessageSender.FRIDAY, responseText)

                _uiState.update {
                    it.copy(
                        lastFridayResponse = responseText
                    )
                }

                // If native audio data is returned, stream directly to low-latency PCM player
                val audioBase64 = audioResult?.base64Audio
                if (!audioBase64.isNullOrBlank() && _uiState.value.isTtsEnabled) {
                    audioPlayer?.enqueueBase64Pcm(audioBase64, audioResult.audioMimeType)
                } else {
                    // If no audio returned or audio disabled, update status
                    _uiState.update {
                        it.copy(
                            mode = FridayMode.IDLE,
                            statusText = "FRIDAY • ONLINE"
                        )
                    }
                }
            } else {
                val errMsg = result.exceptionOrNull()?.message ?: "FRIDAY could not generate native audio."
                _uiState.update {
                    it.copy(
                        mode = FridayMode.IDLE,
                        statusText = "FRIDAY • ONLINE",
                        errorMessage = errMsg
                    )
                }
            }
        }
    }

    private fun checkAndExecuteBossCommand(prompt: String) {
        val lower = prompt.lowercase().trim()

        // 1. Send SMS / Message order
        if (lower.contains("send message") || lower.contains("send sms") || lower.contains("মেসেজ পাঠাও") || lower.contains("sms পাঠাও") || lower.contains("text message")) {
            // Extract recipient and message if possible
            val parts = prompt.split(Regex("(?i)(to|কে|বল|saying|text|message|sms)"))
            val recipient = if (parts.size > 1) parts[1].trim() else ""
            val messageText = if (parts.size > 2) parts.drop(2).joinToString(" ").trim() else prompt
            deviceActionManager.openSmsComposer(recipient, messageText)
            showActionToast("Launching SMS composer for Boss...")
        }

        // 2. Create File / Document order
        else if (lower.contains("create file") || lower.contains("create note") || lower.contains("ফাইল বানাও") || lower.contains("নোট বানাও") || lower.contains("save file") || lower.contains("write a note")) {
            val fileName = "Boss_Note_${System.currentTimeMillis() % 10000}.txt"
            val content = prompt
            deviceActionManager.createFile(fileName, content)
            showActionToast("File created in Boss Vault: $fileName")
        }

        // 3. Install or Open App order
        else if (lower.contains("install app") || lower.contains("install") || lower.contains("ইনস্টল") || lower.contains("download app") || lower.contains("অ্যাপ নামাও")) {
            val appQuery = lower.replace(Regex("(?i)(install app|install|download app|download|অ্যাপ নামাও|ইনস্টল করো|ইনস্টল|please|for me|app)"), "").trim()
            if (appQuery.isNotBlank()) {
                deviceActionManager.installOrSearchApp(appQuery)
                showActionToast("Opening Google Play Store for $appQuery...")
            }
        }

        // 4. Test / Simulate Call Screening
        else if (lower.contains("screen call") || lower.contains("test call") || lower.contains("কল ধরো") || lower.contains("কল সহকারী")) {
            simulateIncomingCall(
                callerName = "Alex Vance (Business Partner)",
                callerNumber = "+1 (555) 349-2810",
                callerMessage = "Hey Mr. Shrabon, Alex here. Let me know when you're available to review the Q3 contracts."
            )
        }
    }

    fun openBossHub() {
        _uiState.update { it.copy(isBossHubOpen = true) }
    }

    fun closeBossHub() {
        _uiState.update { it.copy(isBossHubOpen = false) }
    }

    fun setBossName(name: String) {
        securePreferences.saveBossName(name)
        _uiState.update { it.copy(bossName = name) }
        showActionToast("Boss Name updated to: $name")
    }

    fun toggleCallScreening(enabled: Boolean) {
        securePreferences.saveCallScreeningEnabled(enabled)
        _uiState.update { it.copy(isCallScreeningActive = enabled) }
        showActionToast(if (enabled) "FRIDAY Call Screening: ACTIVE" else "Call Screening: DISABLED")
    }

    fun quickSendSms(recipient: String, message: String) {
        val success = deviceActionManager.openSmsComposer(recipient, message)
        if (success) {
            showActionToast("SMS composer opened.")
        }
    }

    fun quickCreateFile(fileName: String, content: String) {
        val result = deviceActionManager.createFile(fileName, content)
        if (result.isSuccess) {
            showActionToast("Created file: ${result.getOrNull()?.fileName}")
        } else {
            _uiState.update { it.copy(errorMessage = "Failed to create file: ${result.exceptionOrNull()?.message}") }
        }
    }

    fun quickInstallApp(appName: String) {
        deviceActionManager.installOrSearchApp(appName)
        showActionToast("Searching Google Play Store for $appName...")
    }

    fun deleteScreenedCall(id: String) {
        bossActionsRepository.deleteScreenedCall(id)
        showActionToast("Screened call record removed.")
    }

    fun deleteCreatedFile(id: String) {
        bossActionsRepository.deleteFileRecord(id)
        showActionToast("File removed from vault.")
    }

    fun simulateIncomingCall(
        callerName: String = "David (Client)",
        callerNumber: String = "+880 1812-998877",
        callerMessage: String = "Hello Mr. Shrabon, I am calling regarding the server upgrade. Please call me back when free."
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            _uiState.update {
                it.copy(
                    isSimulatingCall = true,
                    mode = FridayMode.PROCESSING,
                    statusText = "INCOMING CALL • SCREENING..."
                )
            }

            // 1. Speak FRIDAY's executive call answering greeting in Leda's voice
            val introText = deviceActionManager.getCallAssistantIntro(callerName)
            val audioResult = geminiRepository.askFridayNativeAudio(
                "You are answering an incoming phone call for your boss Mr. Shrabon who is busy right now. Speak in your warm and professional voice 'Leda': '$introText'"
            )

            if (audioResult.isSuccess) {
                val audio = audioResult.getOrNull()
                if (audio?.base64Audio != null) {
                    audioPlayer?.enqueueBase64Pcm(audio.base64Audio, audio.audioMimeType)
                }
            }

            // Simulate caller leaving message
            delay(4000)

            // Log caller's message in Boss's Screened Call Inbox
            val record = bossActionsRepository.addScreenedCall(
                callerName = callerName,
                callerNumber = callerNumber,
                messageText = callerMessage,
                isUrgent = false
            )

            _uiState.update {
                it.copy(
                    isSimulatingCall = false,
                    lastActionToast = "New Call Screened from $callerName. Message saved to Boss Inbox!"
                )
            }
        }
    }

    private fun showActionToast(message: String) {
        _uiState.update { it.copy(lastActionToast = message) }
    }

    fun clearActionToast() {
        _uiState.update { it.copy(lastActionToast = null) }
    }

    fun sendTextMessage(prompt: String) {
        processUserPrompt(prompt)
    }

    fun openSettings() {
        _uiState.update {
            it.copy(
                isSettingsOpen = true,
                connectionTestResult = null
            )
        }
    }

    fun closeSettings() {
        _uiState.update { it.copy(isSettingsOpen = false) }
    }

    fun openTextMode() {
        _uiState.update { it.copy(isTextModeOpen = true) }
    }

    fun closeTextMode() {
        _uiState.update { it.copy(isTextModeOpen = false) }
    }

    fun openApiKeyDialog() {
        _uiState.update { it.copy(isApiKeyDialogOpen = true) }
    }

    fun closeApiKeyDialog() {
        _uiState.update { it.copy(isApiKeyDialogOpen = false) }
    }

    fun saveApiKey(key: String) {
        securePreferences.saveCustomApiKey(key)
        val hasKey = securePreferences.getEffectiveApiKey().isNotBlank()
        _uiState.update {
            it.copy(
                apiKeyConfigured = hasKey,
                isApiKeyDialogOpen = !hasKey,
                maskedApiKey = securePreferences.getMaskedApiKey(),
                customApiKey = securePreferences.getSavedCustomApiKey(),
                statusText = if (hasKey) "FRIDAY • ONLINE" else "API KEY REQUIRED",
                connectionStatus = if (hasKey) ConnectionStatus.ONLINE else ConnectionStatus.OFFLINE,
                errorMessage = null
            )
        }
    }

    fun selectModel(model: String) {
        securePreferences.saveSelectedModel(model)
        _uiState.update { it.copy(selectedModel = model) }
    }

    fun selectVoice(voice: String) {
        securePreferences.saveSelectedVoice(voice)
        _uiState.update { it.copy(selectedVoice = voice) }
    }

    fun selectVoiceStyle(style: String) {
        securePreferences.saveVoiceStyle(style)
        _uiState.update { it.copy(voiceStyle = style) }
    }

    fun setVoiceSpeed(speed: Float) {
        securePreferences.saveVoiceSpeed(speed)
        _uiState.update { it.copy(voiceSpeed = speed) }
    }

    fun setVolume(volume: Float) {
        securePreferences.saveVolume(volume)
        audioPlayer?.setVolume(volume)
        _uiState.update { it.copy(volume = volume) }
    }

    fun toggleAutoListen(enabled: Boolean) {
        securePreferences.saveAutoListen(enabled)
        _uiState.update { it.copy(isAutoListenEnabled = enabled) }
    }

    fun toggleTts(enabled: Boolean) {
        securePreferences.saveTtsEnabled(enabled)
        _uiState.update { it.copy(isTtsEnabled = enabled) }
    }

    fun testConnection() {
        viewModelScope.launch {
            _uiState.update { it.copy(isTestingConnection = true, connectionTestResult = null) }
            val res = geminiRepository.testConnection()
            _uiState.update {
                it.copy(
                    isTestingConnection = false,
                    connectionTestResult = if (res.isSuccess) {
                        "Latency: ${res.getOrNull()}ms • Operational (Gemini Native Audio)"
                    } else {
                        "Failed: ${res.exceptionOrNull()?.message ?: "Connection failed"}"
                    }
                )
            }
        }
    }

    fun testVoice() {
        viewModelScope.launch(Dispatchers.IO) {
            val samplePrompt = "Hello. I'm FRIDAY, your personal AI assistant. All cognitive, neural, and audio systems are functioning with optimal clarity."
            val result = geminiRepository.askFridayNativeAudio(samplePrompt)
            if (result.isSuccess) {
                val audio = result.getOrNull()
                if (audio?.base64Audio != null) {
                    audioPlayer?.enqueueBase64Pcm(audio.base64Audio, audio.audioMimeType)
                }
            } else {
                _uiState.update { it.copy(errorMessage = result.exceptionOrNull()?.message ?: "Voice preview failed") }
            }
        }
    }

    fun clearConversation() {
        conversationRepository.clear()
        _uiState.update {
            it.copy(
                lastRecognizedSpeech = "",
                lastFridayResponse = ""
            )
        }
    }

    fun dismissError() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    override fun onCleared() {
        super.onCleared()
        activeAudioJob?.cancel()
        audioPlayer?.release()
        liveRecorder?.release()
        microphoneManager?.destroy()
        geminiLiveClient?.disconnect()
    }
}
